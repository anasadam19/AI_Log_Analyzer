"""Small helpers shared by Lambdas and the dashboard."""
from __future__ import annotations

import json
import re
import time
from datetime import datetime, timezone
from decimal import Decimal

_REDACTIONS = [
    (re.compile(r"\b(?:AKIA|ASIA)[A-Z0-9]{16}\b"), "<AWS_KEY_ID>"),
    (re.compile(r"eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}"), "<JWT>"),
    (re.compile(r"(?i)\b(secret|password|passwd|pwd|token|api[_-]?key|authorization)\b(\"?\s*[:=]\s*\"?)[^\s,\"'}]{4,}"),
     r"\1\2<REDACTED>"),
    (re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+"), "<EMAIL>"),
    (re.compile(r"(?<=:)\d{12}(?=:)"), "<ACCOUNT>"),
    (re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b"), "<IP>"),
]


def redact(text: str) -> str:
    """Mask credentials, e-mails, account ids and IPs before text leaves the account (e.g. to an LLM)."""
    if not text:
        return text
    for rx, rep in _REDACTIONS:
        text = rx.sub(rep, text)
    return text


def now_ts() -> float:
    return time.time()


def iso(ts: float | None) -> str:
    if ts is None:
        return ""
    return datetime.fromtimestamp(float(ts), tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")


def to_ddb(obj):
    """Convert python floats to Decimal (DynamoDB) recursively; drop None / empty strings."""
    return json.loads(json.dumps(obj, default=str), parse_float=Decimal)


def from_ddb(obj):
    """Convert Decimal back to int/float recursively."""
    if isinstance(obj, list):
        return [from_ddb(i) for i in obj]
    if isinstance(obj, dict):
        return {k: from_ddb(v) for k, v in obj.items()}
    if isinstance(obj, Decimal):
        return int(obj) if obj == obj.to_integral_value() else float(obj)
    return obj


def chunks(seq, n):
    for i in range(0, len(seq), n):
        yield seq[i:i + n]


def env_list(value: str | None) -> list[str]:
    return [v.strip() for v in (value or "").split(",") if v.strip()]
