"""Synthetic multi-service log generator (demo Lambda, local dashboard mode and tests)."""
from __future__ import annotations

import json
import random
import zlib

SERVICES = ["checkout-api", "payments-db", "inventory-worker", "auth-service", "gateway"]
SCENARIOS = ("db_outage", "throttle", "iam_denied", "memory_leak")


def _line(level, svc, msg, lat=None, rid=None):
    d = {"level": level, "service": svc, "message": msg}
    if lat is not None:
        d["latency_ms"] = round(lat, 1)
    if rid:
        d["request_id"] = rid
    return json.dumps(d)


def lines_for(svc: str, rng: random.Random, scenario: str | None, phase: float = 0.0):
    """Return a list of JSON log lines for ONE minute of one service.

    `scenario` is the active incident (or None). `phase` (0..1) is how far into the incident we are.
    """
    out = []
    rid = lambda: "%08x" % rng.getrandbits(32)  # noqa: E731
    n = rng.randint(6, 12)
    hit = False
    if scenario == "db_outage" and svc in ("payments-db", "checkout-api", "gateway"):
        hit = True
    if scenario == "throttle" and svc == "inventory-worker":
        hit = True
    if scenario == "iam_denied" and svc == "auth-service":
        hit = True
    if scenario == "memory_leak" and svc == "inventory-worker":
        hit = True
    for _ in range(n):
        if hit and rng.random() < 0.55 + 0.3 * phase:
            if scenario == "db_outage":
                if svc == "payments-db":
                    out.append(_line("ERROR", svc, rng.choice([
                        "FATAL: remaining connection slots are reserved for non-replication superuser connections",
                        "too many connections for role app_user (active=%d)" % rng.randint(480, 520)]), rid=rid()))
                elif svc == "checkout-api":
                    out.append(_line("ERROR", svc, "upstream timeout calling payments-db after 5000ms", lat=rng.gauss(5000, 100), rid=rid()))
                else:
                    out.append(_line("ERROR", svc, "HTTP 503 Service Unavailable from checkout-api", lat=rng.gauss(5200, 150), rid=rid()))
            elif scenario == "throttle":
                out.append(_line("ERROR", svc, "ThrottlingException: Rate exceeded for DynamoDB table inventory (consumed=%d)" % rng.randint(900, 1200), rid=rid()))
            elif scenario == "iam_denied":
                out.append(_line("ERROR", svc, "AccessDeniedException: role app-role is not authorized to perform secretsmanager:GetSecretValue", rid=rid()))
            elif scenario == "memory_leak":
                out.append(_line("CRITICAL" if phase > 0.7 and rng.random() < 0.4 else "ERROR", svc,
                                 "java.lang.OutOfMemoryError: Java heap space (heap=%dMB)" % rng.randint(1900, 2048), rid=rid()))
        else:
            base = {"checkout-api": 180, "payments-db": 14, "inventory-worker": 60, "auth-service": 35, "gateway": 90}.get(svc, 50)
            lat = max(1.0, rng.gauss(base, base * 0.15))
            if scenario == "memory_leak" and svc == "inventory-worker":
                lat *= 1 + 3 * phase
            r = rng.random()
            if r < 0.01:
                out.append(_line("ERROR", svc, "transient error contacting cache, retrying (attempt %d)" % rng.randint(1, 3), rid=rid()))
            elif r < 0.04:
                out.append(_line("WARN", svc, "slow response, took %dms" % (lat * 2.2), lat=lat * 2.2, rid=rid()))
            else:
                out.append(_line("INFO", svc, {"checkout-api": "POST /checkout 200", "payments-db": "query ok rows=%d" % rng.randint(1, 50),
                                               "inventory-worker": "processed batch size=%d" % rng.randint(5, 40),
                                               "auth-service": "login ok user=u%d" % rng.randint(1000, 9999),
                                               "gateway": "GET /api/v1/items 200"}.get(svc, "ok"), lat=lat, rid=rid()))
    return out


def generate(now: float, minutes: int = 90, seed: int = 42, scenario: str | None = None, incident_minutes: int = 8):
    """Return [(group, stream, ts_ms, message)] for the last `minutes`; the incident occupies the final `incident_minutes`."""
    rng = random.Random(seed)
    rows = []
    start = now - minutes * 60
    for m in range(minutes):
        t0 = start + m * 60
        active = scenario if (scenario and m >= minutes - incident_minutes) else None
        phase = (m - (minutes - incident_minutes)) / max(1, incident_minutes) if active else 0.0
        for svc in SERVICES:
            for ln in lines_for(svc, rng, active, phase):
                rows.append((f"/aiops/demo/{svc}", "i-0demo%08x" % (zlib.crc32(svc.encode())), int((t0 + rng.random() * 59) * 1000), ln))
    rows.sort(key=lambda r: r[2])
    return rows
