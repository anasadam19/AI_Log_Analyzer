"""SNS (email / chatbots) and optional Slack incoming-webhook notifications."""
from __future__ import annotations

import json
import os
import urllib.request


def publish(subject: str, message: str, topic_arn: str | None = None, sns=None) -> bool:
    topic_arn = topic_arn or os.environ.get("SNS_TOPIC_ARN")
    ok = False
    if topic_arn:
        import boto3
        sns = sns or boto3.client("sns")
        subj = " ".join(subject.encode("ascii", "ignore").decode().split())[:100] or "AIOps"
        sns.publish(TopicArn=topic_arn, Subject=subj, Message=message[:250000])
        ok = True
    hook = os.environ.get("SLACK_WEBHOOK_URL")
    if hook:
        try:
            req = urllib.request.Request(hook, data=json.dumps({"text": f"*{subject}*\n{message}"[:3500]}).encode(),
                                         headers={"Content-Type": "application/json"})
            urllib.request.urlopen(req, timeout=5).read()
            ok = True
        except Exception:  # noqa: BLE001 - never fail the pipeline because Slack is down
            pass
    return ok
