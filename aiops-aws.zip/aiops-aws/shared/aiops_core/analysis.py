"""Anomaly detection, pattern mining, risk scoring and incident correlation (pure python, no numpy)."""
from __future__ import annotations

import hashlib
import math
import re
from collections import Counter, defaultdict

from .events import LEVEL_RANK, instance_from_stream, normalize_message
from .rca import classify

SEVERITY_SCORE = {"ERROR": 2.5, "CRITICAL": 4.0}
INCIDENT_KINDS = {"error", "critical", "burst"}


def _mean_std(xs):
    n = len(xs)
    if n == 0:
        return 0.0, 0.0
    m = sum(xs) / n
    var = sum((x - m) ** 2 for x in xs) / n
    return m, math.sqrt(var)


def detect_anomalies(events, since: float | None = None, z_thresh: float = 3.0, min_samples: int = 10,
                     bucket_s: int = 60, min_burst: int = 3, max_items: int = 5000):
    """Return anomaly dicts for events at/after `since` (all events if None).

    Three detectors:
      1. severity  – every ERROR / CRITICAL event (score 2.5 / 4.0)
      2. latency   – per-service z-score of latency vs a baseline, flagged when z >= z_thresh and >1.5x the mean
      3. burst     – per-service errors-per-bucket z-score vs baseline buckets (zero buckets included)
    The baseline is everything *before* `since` (falls back to all data if too small) so a current
    incident cannot hide itself by inflating the baseline.
    """
    if not events:
        return []
    cur = [e for e in events if since is None or e.ts >= since]
    base = [e for e in events if since is not None and e.ts < since]
    if len(base) < min_samples:
        base = events
    out = []

    # 1) severity
    for e in cur:
        if e.level in SEVERITY_SCORE:
            out.append(dict(ts=e.ts, service=e.service, kind=e.level.lower(), score=SEVERITY_SCORE[e.level],
                            level=e.level, message=e.message[:300], stream=e.stream, latency_ms=e.latency_ms))

    # 2) latency z-score
    by_svc = defaultdict(list)
    for e in base:
        if e.latency_ms is not None:
            by_svc[e.service].append(e.latency_ms)
    stats = {s: _mean_std(v) for s, v in by_svc.items() if len(v) >= min_samples}
    for e in cur:
        if e.latency_ms is None or e.service not in stats:
            continue
        m, sd = stats[e.service]
        if sd <= 0:
            continue
        z = (e.latency_ms - m) / sd
        if z >= z_thresh and e.latency_ms > 1.5 * m:
            out.append(dict(ts=e.ts, service=e.service, kind="latency", score=round(min(z, 10.0), 2), level=e.level,
                            message=f"latency {e.latency_ms:.0f} ms (baseline {m:.0f}±{sd:.0f} ms, z={z:.1f}) {e.message[:160]}",
                            stream=e.stream, latency_ms=e.latency_ms))

    # 3) error bursts per bucket
    errs = defaultdict(lambda: defaultdict(int))
    for e in events:
        if LEVEL_RANK.get(e.level, 0) >= LEVEL_RANK["ERROR"]:
            errs[e.service][int(e.ts // bucket_s)] += 1
    t0 = int(min(e.ts for e in events) // bucket_s)
    cut = int(since // bucket_s) if since is not None else None
    for svc, bk in errs.items():
        base_b = list(range(t0, cut)) if cut is not None and cut - t0 >= 5 else list(range(t0, max(bk) + 1))
        vals = [bk.get(b, 0) for b in base_b]
        m, sd = _mean_std(vals)
        for b, c in sorted(bk.items()):
            if cut is not None and b < cut:
                continue
            z = (c - m) / max(sd, 1.0)
            if c >= min_burst and z >= z_thresh:
                out.append(dict(ts=b * bucket_s, service=svc, kind="burst", score=round(min(z, 10.0), 2), level="ERROR",
                                message=f"{c} errors in {bucket_s}s (baseline {m:.2f}±{sd:.2f}/bucket, z={z:.1f})",
                                stream="", latency_ms=None))
    out.sort(key=lambda a: a["ts"])
    return out[-max_items:]


def mine_patterns(events, top: int = 30, min_level: str = "DEBUG"):
    """Group messages by normalised template; return the `top` most frequent."""
    groups = {}
    floor = LEVEL_RANK[min_level]
    for e in events:
        if LEVEL_RANK.get(e.level, 0) < floor:
            continue
        t = normalize_message(e.message)
        g = groups.get(t)
        if g is None:
            g = groups[t] = dict(template=t, count=0, level=e.level, services=Counter(), first_ts=e.ts, last_ts=e.ts, sample=e.message[:300])
        g["count"] += 1
        g["services"][e.service] += 1
        g["first_ts"] = min(g["first_ts"], e.ts)
        g["last_ts"] = max(g["last_ts"], e.ts)
        if LEVEL_RANK.get(e.level, 0) > LEVEL_RANK.get(g["level"], 0):
            g["level"] = e.level
            g["sample"] = e.message[:300]
    rows = sorted(groups.values(), key=lambda g: g["count"], reverse=True)[:top]
    for g in rows:
        g["services"] = [s for s, _ in g["services"].most_common(5)]
        g["category"] = classify(g["sample"])["category"] if LEVEL_RANK.get(g["level"], 0) >= LEVEL_RANK["WARN"] else ""
    return rows


def risk_scores(events, now: float, window_min: int = 10):
    """Heuristic per-service risk 0-100 = error rate (60) + worsening trend (25) + critical count (15)."""
    w = window_min * 60
    cur, prev = defaultdict(list), defaultdict(list)
    for e in events:
        if now - w <= e.ts <= now:
            cur[e.service].append(e)
        elif now - 2 * w <= e.ts < now - w:
            prev[e.service].append(e)
    rows = []
    for svc in set(cur) | set(prev):
        c, p = cur.get(svc, []), prev.get(svc, [])
        ce = sum(1 for e in c if e.level in SEVERITY_SCORE)
        pe = sum(1 for e in p if e.level in SEVERITY_SCORE)
        cr = ce / len(c) if c else 0.0
        pr = pe / len(p) if p else 0.0
        crit = sum(1 for e in c if e.level == "CRITICAL")
        risk = 60 * min(1, cr / 0.25) + 25 * min(1, max(0.0, cr - pr) / 0.15) + 15 * min(1, crit / 3)
        if len(c) < 3:
            risk *= 0.5
        rows.append(dict(service=svc, risk=round(risk, 1), error_rate=round(cr, 4), trend=round(cr - pr, 4),
                         events=len(c), errors=ce, critical=crit))
    rows.sort(key=lambda r: r["risk"], reverse=True)
    return rows


def build_incidents(anomalies, events=None, window_min: float = 5.0, min_events: int = 2):
    """Cluster error/critical/burst anomalies that are close in time (across services) into incidents.

    Latency-only anomalies are excluded on purpose: they are weak signals and merge unrelated clusters.
    """
    sel = [a for a in anomalies if a["kind"] in INCIDENT_KINDS]
    sel.sort(key=lambda a: a["ts"])
    clusters, cur, last = [], [], None
    for a in sel:
        if last is not None and a["ts"] - last > window_min * 60:
            clusters.append(cur)
            cur = []
        cur.append(a)
        last = a["ts"]
    if cur:
        clusters.append(cur)

    inc = []
    for cl in clusters:
        raw = [a for a in cl if a["kind"] in ("error", "critical")]
        has_burst = any(a["kind"] == "burst" for a in cl)
        has_crit = any(a["kind"] == "critical" for a in cl)
        if len(raw) < min_events and not has_crit and not has_burst:
            continue
        start, end = cl[0]["ts"], cl[-1]["ts"]
        svc_counts = Counter(a["service"] for a in (raw or cl))
        votes = defaultdict(float)
        cls_by_msg = {}
        for a in raw or cl:
            c = classify(a["message"])
            cls_by_msg[a["message"]] = c
            if c["id"] != "unknown":
                votes[c["id"]] += a["score"] * c["conf"]
        if votes:
            top_id = max(votes, key=votes.get)
            top = next(c for c in cls_by_msg.values() if c["id"] == top_id)
        else:
            top = classify("")
        # probable origin: earliest service that shows the dominant category (else earliest erroring service)
        origin = None
        for a in (raw or cl):
            if cls_by_msg[a["message"]]["id"] == top["id"]:
                origin = a["service"]
                break
        origin = origin or (raw or cl)[0]["service"]
        n_err = len(raw)
        n_svc = len(svc_counts)
        if has_crit or n_err >= 50 or (n_svc >= 3 and n_err >= 10):
            sev = "critical"
        elif n_err >= 15 or n_svc >= 2 or has_burst:
            sev = "high"
        elif n_err >= 5:
            sev = "medium"
        else:
            sev = "low"
        tmpl = Counter()
        sample_msg = {}
        for a in raw or cl:
            t = normalize_message(a["message"])
            tmpl[t] += 1
            sample_msg.setdefault(t, a["message"])
        samples = [dict(message=sample_msg[t][:300], count=n) for t, n in tmpl.most_common(8)]
        targets = {"lambda": sorted({s.split(":", 1)[1] for s in svc_counts if s.startswith("lambda:")}), "instances": []}
        inst = {instance_from_stream(a.get("stream", "")) for a in cl}
        targets["instances"] = sorted(i for i in inst if i)
        iid = hashlib.sha1(f"{origin}|{top['id']}|{int(start // 900)}".encode()).hexdigest()[:12]
        title = f"{top['category']} in {origin}" + (f" (+{n_svc - 1} services)" if n_svc > 1 else "")
        inc.append(dict(id=iid, title=title, status="open", severity=sev, category=top["category"], category_id=top["id"],
                        confidence=top["conf"], hint=top["hint"], runbook=top["runbook"], root_service=origin,
                        services=dict(svc_counts), start_ts=start, end_ts=end, event_count=n_err, burst=has_burst,
                        score=round(min(100.0, sum(a["score"] for a in cl) * 2), 1), samples=samples, targets=targets))
    inc.sort(key=lambda i: i["start_ts"], reverse=True)
    return inc


def severity_rank(s: str) -> int:
    return {"low": 0, "medium": 1, "high": 2, "critical": 3}.get(s, 0)


def summarize_levels(events):
    c = Counter(e.level for e in events)
    return {l: c.get(l, 0) for l in ("DEBUG", "INFO", "WARN", "ERROR", "CRITICAL")}
