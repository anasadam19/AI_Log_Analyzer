"""Log event model + parsers for the log formats AWS services produce."""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field, asdict

LEVELS = ["DEBUG", "INFO", "WARN", "ERROR", "CRITICAL"]
LEVEL_RANK = {l: i for i, l in enumerate(LEVELS)}
_ALIASES = {"FATAL": "CRITICAL", "SEVERE": "CRITICAL", "EMERGENCY": "CRITICAL", "ALERT": "CRITICAL",
            "ERR": "ERROR", "WARNING": "WARN", "TRACE": "DEBUG", "NOTICE": "INFO"}

_LEVEL_RE = re.compile(r"\b(CRITICAL|FATAL|SEVERE|ERROR|ERR|WARN(?:ING)?|INFO|DEBUG|TRACE)\b", re.I)
_ERR_WORDS = re.compile(
    r"(exception|traceback|failed|failure|fatal|panic|timed out|timeout|refused|unreachable|"
    r"out of memory|oomkilled|segfault|throttl|runtime\.\w*error)", re.I)
_LAT_RE = re.compile(r"(?:latency|duration|took|elapsed|response[_ ]?time)[\"']?\s*[=:]?\s*(\d+(?:\.\d+)?)\s*(ms|s|sec)?\b", re.I)
_REPORT_RE = re.compile(r"REPORT RequestId:.*?\bDuration:\s*([\d.]+)\s*ms")
_INSTANCE_RE = re.compile(r"(i-[0-9a-f]{8,17})")

_MSG_KEYS = ("message", "msg", "log", "event", "error", "errorMessage", "detail")
_LVL_KEYS = ("level", "severity", "loglevel", "log_level", "levelname", "lvl", "@l")
_LAT_KEYS = ("latency_ms", "duration_ms", "elapsed_ms", "responseTime", "response_time_ms", "latency", "integrationLatency")


@dataclass
class Event:
    ts: float                 # epoch seconds
    service: str
    stream: str
    level: str
    message: str
    latency_ms: float | None = None
    group: str = ""
    tags: list = field(default_factory=list)

    def to_dict(self):
        return asdict(self)


def service_from_group(group: str) -> str:
    g = group or ""
    parts = [p for p in g.split("/") if p]
    if g.startswith("/aws/lambda/") and len(parts) >= 3:
        return f"lambda:{parts[2]}"
    if g.startswith("/aws/rds/") and len(parts) >= 4:
        return f"rds:{parts[3]}"
    if g.startswith("/aws/ecs/") and len(parts) >= 3:
        return f"ecs:{parts[-1]}"
    if g.startswith("/ecs/") and len(parts) >= 2:
        return f"ecs:{parts[1]}"
    if g.startswith("/aws/eks/") and len(parts) >= 3:
        return f"eks:{parts[2]}"
    if g.startswith("/aws/apigateway/") or g.startswith("API-Gateway-Execution-Logs"):
        return "apigw:" + (parts[-1] if parts else "api")
    if "flowlog" in g.lower() or g.startswith("/aws/vpc/"):
        return "vpcflow"
    if g.startswith("/aws/cloudtrail"):
        return "cloudtrail"
    if g.startswith("/aws/events/"):
        return "events:" + parts[-1]
    if g.startswith("/aiops/demo/"):
        return "demo:" + parts[-1]
    if g.startswith("/aiops/app/"):
        return "app:" + parts[-1]
    return ":".join(parts)[:60] or "unknown"


def _norm_level(v) -> str | None:
    if v is None:
        return None
    s = str(v).strip().upper()
    s = _ALIASES.get(s, s)
    return s if s in LEVEL_RANK else None


def _num(v):
    try:
        f = float(v)
        return f if f >= 0 else None
    except (TypeError, ValueError):
        return None


def _parse_json(obj: dict):
    """Return (level, message, latency_ms, tags) for a structured log line."""
    tags: list = []
    # --- CloudTrail record
    if "eventName" in obj and "eventSource" in obj:
        code = obj.get("errorCode")
        msg = f"{obj['eventSource']}:{obj['eventName']}"
        lvl = "INFO"
        if code:
            msg += f" {code} {str(obj.get('errorMessage', ''))[:160]}"
            if re.search(r"AccessDenied|Unauthorized|Forbidden", str(code), re.I):
                lvl, tags = "WARN", ["security"]
            elif re.search(r"Throttl|InternalFailure|ServiceUnavailable|InternalError", str(code), re.I):
                lvl = "ERROR"
            else:
                lvl = "WARN"
        return lvl, msg, None, tags + ["cloudtrail"]
    # --- EventBridge envelope (GuardDuty, Health, alarms ...)
    if "detail-type" in obj and "source" in obj:
        src, dt, det = obj["source"], obj["detail-type"], obj.get("detail") or {}
        msg = f"{src} {dt}"
        lvl = "INFO"
        if src == "aws.guardduty":
            sev = _num(det.get("severity")) or 0
            msg += f" {det.get('type', '')} severity={sev}"
            lvl = "CRITICAL" if sev >= 8 else "ERROR" if sev >= 7 else "WARN"
            tags = ["security"]
        elif dt == "CloudWatch Alarm State Change":
            st = (det.get("state") or {}).get("value")
            msg += f" {det.get('alarmName', '')} -> {st}"
            lvl = "ERROR" if st == "ALARM" else "INFO"
        elif src == "aws.health":
            msg += f" {det.get('eventTypeCode', '')}"
            lvl = "WARN"
        elif src == "aws.config":
            msg += f" {det.get('configRuleName', '')} {det.get('newEvaluationResult', {}).get('complianceType', '')}"
            lvl = "WARN" if "NON_COMPLIANT" in msg else "INFO"
        return lvl, msg, None, tags + ["event"]
    # --- generic application JSON
    lvl = None
    for k in _LVL_KEYS:
        if k in obj:
            lvl = _norm_level(obj[k])
            if lvl:
                break
    msg = None
    for k in _MSG_KEYS:
        if k in obj and obj[k]:
            msg = obj[k] if isinstance(obj[k], str) else json.dumps(obj[k])[:400]
            break
    if msg is None:
        msg = json.dumps(obj)[:400]
    if lvl is None:
        status = _num(obj.get("statusCode") or obj.get("status") or obj.get("status_code"))
        if status and status >= 500:
            lvl = "ERROR"
        elif status and status >= 400:
            lvl = "WARN"
    lat = None
    for k in _LAT_KEYS:
        if k in obj and _num(obj[k]) is not None:
            lat = _num(obj[k])
            break
    return lvl, msg, lat, tags


def parse_event(group: str, stream: str, ts_ms: int, message: str) -> Event:
    message = (message or "").rstrip("\n")
    service = service_from_group(group)
    lvl: str | None = None
    lat: float | None = None
    tags: list = []
    text = message
    s = message.lstrip()
    if s.startswith("{") and s.endswith("}"):
        try:
            obj = json.loads(s)
            if isinstance(obj, dict):
                lvl, text, lat, tags = _parse_json(obj)
                if obj.get("service") and group.startswith(("/aiops/demo/", "/aiops/app/")):
                    service = f"{service.split(':')[0]}:{obj['service']}"
        except ValueError:
            pass
    if lvl is None:
        m = _REPORT_RE.search(text)
        if m:
            lat = float(m.group(1))
            lvl = "INFO"
        elif text.startswith(("START RequestId", "END RequestId", "INIT_START", "EXTENSION")):
            lvl = "DEBUG"
        elif "Task timed out after" in text:
            lvl = "ERROR"
        else:
            lm = _LEVEL_RE.search(text)
            if lm:
                lvl = _norm_level(lm.group(1))
            elif _ERR_WORDS.search(text):
                lvl = "ERROR"
            elif " REJECT " in f" {text} " and "vpcflow" == service:
                lvl, tags = "WARN", ["network"]
            else:
                lvl = "INFO"
    if lat is None and not text.startswith("REPORT"):
        lm = _LAT_RE.search(text)
        if lm:
            val = float(lm.group(1))
            unit = (lm.group(2) or "ms").lower()
            lat = val * 1000 if unit in ("s", "sec") else val
    return Event(ts=ts_ms / 1000.0, service=service, stream=stream or "", level=lvl or "INFO",
                 message=text[:2000], latency_ms=lat, group=group, tags=tags)


def instance_from_stream(stream: str) -> str | None:
    m = _INSTANCE_RE.search(stream or "")
    return m.group(1) if m else None


_NORMALIZERS = [
    (re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", re.I), "<UUID>"),
    (re.compile(r"\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:[.,]\d+)?Z?"), "<TS>"),
    (re.compile(r"\barn:aws[\w-]*:[^\s\"']+"), "<ARN>"),
    (re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b"), "<IP>"),
    (re.compile(r"\bi-[0-9a-f]{8,17}\b"), "<INSTANCE>"),
    (re.compile(r"\b0x[0-9a-f]+\b|\b[0-9a-f]{12,}\b", re.I), "<HEX>"),
    (re.compile(r"\b\d+(?:\.\d+)?\b"), "<N>"),
]


def normalize_message(msg: str) -> str:
    """Collapse variable tokens so 'same-shaped' messages share one template."""
    out = (msg or "")[:300]
    for rx, rep in _NORMALIZERS:
        out = rx.sub(rep, out)
    return re.sub(r"\s+", " ", out).strip()
