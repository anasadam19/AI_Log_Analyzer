"""Signature knowledge base for root-cause classification.

Order matters: the first matching signature wins, so SPECIFIC signatures come before GENERIC ones
(e.g. 'lock wait timeout' must be tested before the generic 'timeout' network rule).
`runbook` is the id of an allow-listed remediation (see lambdas/remediator) or None.
"""
from __future__ import annotations

import re

RUNBOOKS = ("restart_service", "reboot_instance", "lambda_scale_config", "clean_disk")

_S = [
    ("lambda_timeout", "Lambda timeout", r"Task timed out after", 0.95, "lambda_scale_config",
     "Function exceeded its configured timeout. Check downstream latency, raise Timeout/MemorySize (more memory = more CPU), "
     "and add client-side timeouts shorter than the function timeout."),
    ("memory", "Memory exhaustion", r"signal: killed|Runtime\.OutOfMemory|MemoryError|OutOfMemoryError|Cannot allocate memory|Out of memory: Kill|Java heap space|OOMKilled", 0.9, "lambda_scale_config",
     "Process ran out of memory. Increase memory, look for leaks / unbounded caches or oversized payloads, and add memory alarms."),
    ("import_error", "Deployment / packaging error", r"Runtime\.ImportModuleError|ModuleNotFoundError|No module named|Cannot find module|Runtime\.HandlerNotFound", 0.95, None,
     "Code package is missing a dependency or handler. Roll back to the last good version/alias and fix the build artifact."),
    ("db_lock", "Database lock contention", r"lock wait timeout|deadlock|could not obtain lock|lock timeout", 0.9, None,
     "Transactions are blocking each other. Find long-running transactions, shorten them, add indexes and retry with back-off."),
    ("db_conn", "Database connectivity / connection exhaustion",
     r"too many connections|remaining connection slots|connection pool (?:exhausted|timeout)|could not connect to server|Can't connect to MySQL|PSQLException|SQLSTATE\[HY000\]|db(?:/| ).{0,20}unreachable", 0.9, None,
     "The database is refusing/starving connections. Check max_connections, pool sizes and leaked connections; consider RDS Proxy; verify the DB is healthy and SGs allow traffic."),
    ("db_slow", "Slow database query", r"slow query|statement timeout|canceling statement due to statement timeout|query (?:took|exceeded)", 0.8, None,
     "Queries are slow. Inspect Performance Insights / slow-query log, add missing indexes, and review recent schema or traffic changes."),
    ("throttle", "API throttling / rate limit",
     r"ThrottlingException|Rate exceeded|TooManyRequests|ProvisionedThroughputExceeded|RequestLimitExceeded|\bThrottl|(?:status|code|http)\W{0,3}429\b|SlowDown", 0.9, None,
     "A service quota or provisioned capacity is exhausted. Add exponential back-off with jitter, raise the quota/capacity, or smooth the burst with a queue."),
    ("iam_denied", "Permission / IAM denied",
     r"AccessDenied|UnauthorizedOperation|not authorized to perform|is not authorized|Forbidden|(?:status|code|http)\W{0,3}403\b", 0.9, None,
     "A role/policy is missing a permission. Read the denied action in the message, check the role policy, SCPs and resource policies (CloudTrail shows the caller)."),
    ("disk", "Disk space exhaustion", r"No space left on device|disk (?:is )?full|ENOSPC|Disk quota exceeded", 0.95, "clean_disk",
     "Filesystem is full. Rotate/delete logs and temp files, enlarge the EBS volume, and add disk-usage alarms."),
    ("tls", "TLS / certificate problem", r"certificate (?:has )?expired|CERTIFICATE_VERIFY_FAILED|x509:|handshake failure|SSL(?:Error| error)", 0.85, None,
     "Certificate is expired/untrusted. Renew via ACM, check the trust store and the clock on the host."),
    ("network", "Network / dependency connectivity",
     r"ECONNRESET|ECONNREFUSED|ETIMEDOUT|Name or service not known|getaddrinfo|UnknownHostException|Connection reset|Network is unreachable|connect(?:ion)? timed? ?out|Read timed out|ConnectTimeout|upstream timeout", 0.75, None,
     "Calls to a dependency fail or time out. Check security groups/NACLs/route tables/DNS, the health of the target service and add retries with timeouts."),
    ("upstream_5xx", "Upstream dependency failure", r"\b(?:502|503|504)\b|Bad Gateway|Service Unavailable|Gateway Time-?out|circuit breaker (?:is )?open", 0.7, None,
     "An upstream returns 5xx. Find the failing upstream in the cluster's earliest events and fix it first; enable circuit breakers and fallbacks."),
    ("config_missing", "Missing configuration / resource", r"ParameterNotFound|ResourceNotFoundException|NoSuchKey|NoSuchBucket|KeyError|(?:environment variable|env var).{0,30}(?:not set|missing)", 0.7, None,
     "A referenced parameter/secret/bucket/key does not exist. Verify names per environment and the latest deployment/config change."),
    ("service_down", "Service crash / unhealthy", r"Active: failed|entered failed state|Main process exited|service .{0,40}(?:failed|not running)|health ?check failed|unhealthy", 0.85, "restart_service",
     "A process stopped or fails health checks. Restart it, read the last lines of its journal for the crash reason and add a systemd Restart= policy."),
    ("cpu", "CPU saturation", r"CPU.{0,20}(?:100%|saturat|too high)|soft lockup|load average", 0.7, None,
     "CPU is saturated. Check for runaway processes or traffic spikes, scale out, or right-size the instance."),
    ("app_exception", "Unhandled application exception", r"Traceback|Unhandled|panic:|NullPointer|TypeError|ValueError|Exception", 0.5, None,
     "Application raised an unhandled exception. Use the stack trace in the log sample to locate the faulty code path and the deployment that introduced it."),
]
SIGNATURES = [dict(id=i, category=c, rx=re.compile(p, re.I), conf=cf, runbook=rb, hint=h) for i, c, p, cf, rb, h in _S]
UNKNOWN = dict(id="unknown", category="Unclassified", conf=0.2, runbook=None,
               hint="No known signature matched. Inspect the sample messages and recent deployments/changes around the start time.")


def classify(message: str) -> dict:
    """Return the first matching signature as {id, category, conf, runbook, hint}."""
    for s in SIGNATURES:
        if s["rx"].search(message or ""):
            return {k: s[k] for k in ("id", "category", "conf", "runbook", "hint")}
    return dict(UNKNOWN)
