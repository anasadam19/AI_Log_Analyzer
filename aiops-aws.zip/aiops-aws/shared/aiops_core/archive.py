"""Read log files that Firehose / CloudTrail wrote to the S3 archive and turn them into Events."""
from __future__ import annotations

import gzip
import json

from .events import parse_event


def _docs(text: str):
    """Yield every JSON document in a string (Firehose concatenates batches without a delimiter)."""
    dec = json.JSONDecoder()
    i, n = 0, len(text)
    while i < n:
        while i < n and text[i] in " \r\n\t":
            i += 1
        if i >= n:
            break
        try:
            obj, j = dec.raw_decode(text, i)
        except ValueError:
            nl = text.find("\n", i)
            i = n if nl < 0 else nl + 1
            continue
        yield obj
        i = j


def parse_archive_blob(data: bytes, max_events: int = 50000):
    """Parse an S3 object (gzip or plain) into a list of Event.

    Supports:
      * CloudWatch Logs subscription batches (Firehose output):  {"messageType":"DATA_MESSAGE","logGroup":..,"logEvents":[..]}
      * CloudTrail log files:                                    {"Records":[{...}]}
      * plain JSON-lines / text (one event per line)
    """
    try:
        data = gzip.decompress(data)  # handles multi-member gzip
    except (OSError, EOFError):
        pass
    text = data.decode("utf-8", errors="replace")
    out = []
    for doc in _docs(text):
        if not isinstance(doc, dict):
            continue
        if "logEvents" in doc:
            if doc.get("messageType") == "CONTROL_MESSAGE":
                continue
            g, s = doc.get("logGroup", "archive"), doc.get("logStream", "")
            for e in doc["logEvents"]:
                out.append(parse_event(g, s, int(e["timestamp"]), e["message"]))
        elif "Records" in doc:
            from datetime import datetime
            for r in doc["Records"]:
                try:
                    ts = datetime.fromisoformat(r["eventTime"].replace("Z", "+00:00")).timestamp()
                except (KeyError, ValueError):
                    ts = 0
                out.append(parse_event("/aws/cloudtrail/archive", "", int(ts * 1000), json.dumps(r)))
        else:
            ts = doc.get("timestamp", 0)
            out.append(parse_event("/archive/jsonl", "", int(ts) if ts else 0, json.dumps(doc)))
        if len(out) >= max_events:
            break
    if not out:  # plain text fallback
        for ln in text.splitlines()[:max_events]:
            if ln.strip():
                out.append(parse_event("/archive/text", "", 0, ln))
    return out
