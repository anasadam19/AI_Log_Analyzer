"""LLM access: Amazon Bedrock (Converse API, default) or local Ollama (dev only)."""
from __future__ import annotations

import json
import os
import re
import urllib.request

from .rca import RUNBOOKS
from .util import redact, iso


class LLMError(RuntimeError):
    pass


def provider() -> str:
    return os.environ.get("LLM_PROVIDER", "bedrock").lower()


def model_id() -> str:
    return os.environ.get("BEDROCK_MODEL_ID", "us.anthropic.claude-haiku-4-5-20251001-v1:0")


def _bedrock_client(region=None):
    import boto3
    from botocore.config import Config
    return boto3.client("bedrock-runtime", region_name=region or os.environ.get("BEDROCK_REGION") or os.environ.get("AWS_REGION"),
                        config=Config(read_timeout=90, connect_timeout=10, retries={"max_attempts": 3, "mode": "standard"}))


def _norm_messages(messages):
    """Bedrock requires alternating roles starting with 'user'."""
    out = []
    for m in messages:
        role = "assistant" if m["role"] == "assistant" else "user"
        if out and out[-1]["role"] == role:
            out[-1]["content"] += "\n\n" + m["content"]
        else:
            out.append({"role": role, "content": m["content"]})
    while out and out[0]["role"] != "user":
        out.pop(0)
    return out


def converse(system: str, messages: list, max_tokens: int = 1200, temperature: float = 0.2, model: str | None = None,
             client=None) -> dict:
    """Single-shot completion. Returns {text, input_tokens, output_tokens, model, provider}."""
    messages = _norm_messages(messages)
    if provider() == "ollama":
        return _ollama(system, messages, temperature)
    if provider() == "mock":
        return _mock(system, messages)
    model = model or model_id()
    try:
        client = client or _bedrock_client()
        kwargs = dict(modelId=model, system=[{"text": system}],
                      messages=[{"role": m["role"], "content": [{"text": m["content"]}]} for m in messages],
                      inferenceConfig={"maxTokens": max_tokens, "temperature": temperature})
        gid = os.environ.get("BEDROCK_GUARDRAIL_ID")
        if gid:
            kwargs["guardrailConfig"] = {"guardrailIdentifier": gid, "guardrailVersion": os.environ.get("BEDROCK_GUARDRAIL_VERSION", "DRAFT")}
        r = client.converse(**kwargs)
    except Exception as e:  # noqa: BLE001 - surface any SDK/network problem uniformly
        raise LLMError(f"Bedrock call failed: {e}") from e
    text = "".join(b.get("text", "") for b in r["output"]["message"]["content"])
    u = r.get("usage", {})
    return dict(text=text, input_tokens=u.get("inputTokens", 0), output_tokens=u.get("outputTokens", 0), model=model, provider="bedrock")


def converse_stream(system: str, messages: list, max_tokens: int = 1200, temperature: float = 0.3, model: str | None = None, client=None):
    """Generator yielding text chunks (Bedrock ConverseStream)."""
    messages = _norm_messages(messages)
    if provider() == "ollama":
        yield _ollama(system, messages, temperature)["text"]
        return
    if provider() == "mock":
        for w in _mock(system, messages)["text"].split(" "):
            yield w + " "
        return
    model = model or model_id()
    try:
        client = client or _bedrock_client()
        r = client.converse_stream(modelId=model, system=[{"text": system}],
                                   messages=[{"role": m["role"], "content": [{"text": m["content"]}]} for m in messages],
                                   inferenceConfig={"maxTokens": max_tokens, "temperature": temperature})
        for ev in r["stream"]:
            d = ev.get("contentBlockDelta")
            if d:
                yield d["delta"].get("text", "")
    except Exception as e:  # noqa: BLE001
        raise LLMError(f"Bedrock stream failed: {e}") from e


def _mock(system, messages):
    """Offline stand-in used for local dashboard demos and tests (LLM_PROVIDER=mock)."""
    q = messages[-1]["content"] if messages else ""
    if system == FIX_SYSTEM:
        title = next((l.split(":", 1)[1].strip() for l in q.splitlines() if l.startswith("Title:")), "incident")
        hint = next((l.split(":", 1)[1].strip() for l in q.splitlines() if l.startswith("Rule-based hint:")), "")
        text = json.dumps(dict(summary=f"[mock] {title}. {hint}", probable_root_cause=title, confidence=0.6,
                               evidence=["see sample messages"], recommended_actions=[dict(step=hint or "investigate", how="console", risk="low")],
                               runbook="none", prevention=["add alarms"]))
    else:
        text = "[mock assistant] I only echo in offline mode. Your question was: " + q[:300]
    return dict(text=text, input_tokens=0, output_tokens=0, model="mock", provider="mock")


def _ollama(system, messages, temperature):
    host = os.environ.get("OLLAMA_HOST", "http://localhost:11434")
    body = json.dumps({"model": os.environ.get("OLLAMA_MODEL", "llama3.2"), "stream": False, "options": {"temperature": temperature},
                       "messages": [{"role": "system", "content": system}] + messages}).encode()
    try:
        req = urllib.request.Request(f"{host}/api/chat", data=body, headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=120) as r:
            d = json.loads(r.read())
    except Exception as e:  # noqa: BLE001
        raise LLMError(f"Ollama call failed: {e}") from e
    return dict(text=d["message"]["content"], input_tokens=d.get("prompt_eval_count", 0), output_tokens=d.get("eval_count", 0),
                model=os.environ.get("OLLAMA_MODEL", "llama3.2"), provider="ollama")


def extract_json(text: str):
    """Pull the first JSON object out of an LLM answer (handles ```json fences and chatter)."""
    t = text.strip()
    t = re.sub(r"^```(?:json)?|```$", "", t, flags=re.M).strip()
    start = t.find("{")
    if start < 0:
        raise ValueError("no JSON object in model output")
    depth = 0
    in_str = False
    esc = False
    for i in range(start, len(t)):
        ch = t[i]
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
        elif ch == '"':
            in_str = True
        elif ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return json.loads(t[start:i + 1])
    raise ValueError("unterminated JSON object")


FIX_SYSTEM = (
    "You are a senior AWS site-reliability engineer. You analyse an automatically detected incident and produce a concise, "
    "actionable diagnosis. Use ONLY the evidence provided; if evidence is insufficient say so and lower your confidence. "
    "Never invent resource names. Answer with a single JSON object and nothing else."
)


def build_fix_prompt(incident: dict) -> str:
    samples = "\n".join(f"- ({s['count']}x) {redact(s['message'])}" for s in incident.get("samples", [])[:8])
    svc = ", ".join(f"{k} ({v} errors)" for k, v in sorted(incident.get("services", {}).items(), key=lambda kv: -kv[1])[:8])
    schema = {
        "summary": "2-3 sentence plain-English description of what happened and the impact",
        "probable_root_cause": "single most likely cause, naming the originating service",
        "confidence": "number 0..1",
        "evidence": ["short bullet citing a log line or pattern"],
        "recommended_actions": [{"step": "what to do", "how": "AWS console path or CLI command", "risk": "low|medium|high"}],
        "runbook": f"one of {list(RUNBOOKS)} or 'none' - an automated action that is SAFE for this incident",
        "prevention": ["longer-term fix"],
    }
    return (
        f"INCIDENT {incident.get('id')}\nTitle: {incident.get('title')}\nSeverity: {incident.get('severity')}\n"
        f"Window: {iso(incident.get('start_ts'))} -> {iso(incident.get('end_ts'))}\n"
        f"Rule-based category: {incident.get('category')} (confidence {incident.get('confidence')})\n"
        f"Originating service (earliest): {incident.get('root_service')}\nAffected services: {svc}\n"
        f"Error burst detected: {incident.get('burst')}\nTargets: {json.dumps(incident.get('targets', {}))}\n\n"
        f"Most frequent error messages:\n{samples}\n\nRule-based hint: {incident.get('hint')}\n\n"
        f"Return JSON with exactly this shape:\n{json.dumps(schema, indent=2)}"
    )


def chat_system(context: str) -> str:
    return (
        "You are the AIOps assistant embedded in an AWS operations dashboard. Answer using the CONTEXT (incidents, risk scores, "
        "log samples) and general AWS knowledge. Be concise; use bullet points and exact AWS CLI commands where helpful. "
        "Say clearly when the context does not contain the answer. Never request or reveal credentials.\n\nCONTEXT:\n" + context
    )
