#!/usr/bin/env python3
"""Find a Bedrock model/inference-profile that actually answers a Converse call in this account + region.

  python scripts/bedrock_check.py                 # tries sensible candidates, prints the first that works
  python scripts/bedrock_check.py --model <id>    # test one specific id
  python scripts/bedrock_check.py --list          # list Anthropic / Amazon text models and inference profiles

Prints ONLY the working model id on stdout (diagnostics go to stderr) so deploy.sh can capture it.
"""
import argparse
import os
import sys

import boto3
from botocore.exceptions import ClientError


def log(*a):
    print(*a, file=sys.stderr)


def geo(region):
    return "us" if region.startswith(("us-", "ca-")) else "eu" if region.startswith("eu-") else "apac" if region.startswith("ap-") else "us"


def candidates(region):
    g = geo(region)
    return [
        f"{g}.anthropic.claude-haiku-4-5-20251001-v1:0",
        "global.anthropic.claude-haiku-4-5-20251001-v1:0",
        "anthropic.claude-haiku-4-5-20251001-v1:0",
        f"{g}.anthropic.claude-sonnet-4-5-20250929-v1:0",
        f"{g}.amazon.nova-lite-v1:0",
        "amazon.nova-lite-v1:0",
        f"{g}.amazon.nova-micro-v1:0",
        f"{g}.anthropic.claude-3-5-haiku-20241022-v1:0",
        "anthropic.claude-3-haiku-20240307-v1:0",
    ]


def try_model(rt, model):
    try:
        r = rt.converse(modelId=model, messages=[{"role": "user", "content": [{"text": "Reply with the single word OK."}]}],
                        inferenceConfig={"maxTokens": 20, "temperature": 0})
        txt = "".join(b.get("text", "") for b in r["output"]["message"]["content"]).strip()
        return True, txt
    except ClientError as e:
        return False, f"{e.response['Error']['Code']}: {e.response['Error']['Message'][:160]}"
    except Exception as e:  # noqa: BLE001
        return False, str(e)[:160]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--region", default=os.environ.get("BEDROCK_REGION") or os.environ.get("AWS_REGION") or boto3.session.Session().region_name)
    ap.add_argument("--model")
    ap.add_argument("--list", action="store_true")
    a = ap.parse_args()
    if not a.region:
        sys.exit("No region: set AWS_REGION or pass --region")
    rt = boto3.client("bedrock-runtime", region_name=a.region)
    if a.list:
        b = boto3.client("bedrock", region_name=a.region)
        for p in ("Anthropic", "Amazon"):
            for m in b.list_foundation_models(byProvider=p)["modelSummaries"]:
                if "TEXT" in m.get("outputModalities", []) and "ON_DEMAND" in m.get("inferenceTypesSupported", []) + ["ON_DEMAND"]:
                    print(m["modelId"])
        for pr in b.list_inference_profiles(maxResults=100)["inferenceProfileSummaries"]:
            print(pr["inferenceProfileId"])
        return
    for m in ([a.model] if a.model else candidates(a.region)):
        ok, msg = try_model(rt, m)
        log(f"  {'OK  ' if ok else 'FAIL'} {m}  ->  {msg}")
        if ok:
            print(m)
            return
    log("\nNo model worked. Typical fixes:\n"
        " * Bedrock console > Model access / Model catalog: request access (Anthropic models need a one-time use-case form).\n"
        " * Make sure the IAM identity running this has bedrock:InvokeModel.\n"
        " * Use a region where the model/inference profile is offered, then pass BEDROCK_REGION / BEDROCK_MODEL_ID.\n"
        " * Run with --list to see ids available to you.")
    sys.exit(2)


if __name__ == "__main__":
    main()
