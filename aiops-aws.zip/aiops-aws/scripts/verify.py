#!/usr/bin/env python3
"""Post-deployment health check of every layer of the platform. Exit code 0 = all good.   python3 scripts/verify.py"""
import json
import os
import sys
import urllib.request

import boto3

P = os.environ.get("PROJECT", "aiops")
R = os.environ.get("AWS_REGION") or os.environ.get("AWS_DEFAULT_REGION") or boto3.session.Session().region_name
bad = 0


def check(name, ok, detail=""):
    global bad
    print(f"{'PASS' if ok else 'FAIL'}  {name}  {detail}")
    bad += (not ok)


cf = boto3.client("cloudformation", region_name=R)
for s in ("01-foundation", "02-log-aggregation", "03-engine", "04-dashboard"):
    try:
        st = cf.describe_stacks(StackName=f"{P}-{s}")["Stacks"][0]
        check(f"stack {s}", st["StackStatus"].endswith("_COMPLETE") and "ROLLBACK" not in st["StackStatus"], st["StackStatus"])
    except Exception as e:  # noqa: BLE001
        check(f"stack {s}", False, str(e)[:80])

fh = boto3.client("firehose", region_name=R)
try:
    d = fh.describe_delivery_stream(DeliveryStreamName=f"{P}-cwl-archive")["DeliveryStreamDescription"]
    check("Firehose archive stream", d["DeliveryStreamStatus"] == "ACTIVE", d["DeliveryStreamStatus"])
except Exception as e:  # noqa: BLE001
    check("Firehose archive stream", False, str(e)[:80])

logs = boto3.client("logs", region_name=R)
groups = [g["logGroupName"] for p in logs.get_paginator("describe_log_groups").paginate() for g in p["logGroups"]]
sub = 0
for g in groups[:200]:
    if any(f["filterName"] == "aiops-archive" for f in logs.describe_subscription_filters(logGroupName=g)["subscriptionFilters"]):
        sub += 1
check("log groups archived to S3", sub > 0, f"{sub}/{min(len(groups), 200)} groups subscribed (excluded system groups are expected)")

lam = boto3.client("lambda", region_name=R)
try:
    r = lam.invoke(FunctionName=f"{P}-sys-analyzer", Payload=b"{}")
    body = json.loads(r["Payload"].read())
    check("analyzer Lambda", "FunctionError" not in r and "events" in body, str(body)[:120])
except Exception as e:  # noqa: BLE001
    check("analyzer Lambda", False, str(e)[:100])

ddb = boto3.resource("dynamodb", region_name=R).Table(f"{P}-state")
snap = ddb.get_item(Key={"pk": "SNAPSHOT", "sk": "latest"}).get("Item")
check("DynamoDB snapshot written", bool(snap), f"events={snap and snap.get('events')}")

try:
    outs = {o["OutputKey"]: o["OutputValue"] for o in cf.describe_stacks(StackName=f"{P}-04-dashboard")["Stacks"][0]["Outputs"]}
    iid = outs["InstanceId"]
    elb = boto3.client("elbv2", region_name=R)
    tg = elb.describe_target_groups(Names=[f"{P}-dashboard-tg"])["TargetGroups"][0]["TargetGroupArn"]
    th = elb.describe_target_health(TargetGroupArn=tg)["TargetHealthDescriptions"][0]["TargetHealth"]
    check("ALB target healthy", th["State"] == "healthy", f"{th['State']} {th.get('Reason', '')}")
    try:
        url = outs["DashboardUrl"] + "/_stcore/health"
        ok = urllib.request.urlopen(url, timeout=8).read().strip() == b"ok"
        check("dashboard reachable via ALB", ok, url)
    except Exception as e:  # noqa: BLE001
        check("dashboard reachable via ALB", False, f"{e} (is your IP in AllowedCidr?)")
except Exception as e:  # noqa: BLE001
    check("dashboard", False, str(e)[:100])

try:
    eng = {p["ParameterKey"]: p["ParameterValue"] for p in cf.describe_stacks(StackName=f"{P}-03-engine")["Stacks"][0]["Parameters"]}
    if eng.get("LlmProvider") == "none":
        print("SKIP  Bedrock check  (LLM_PROVIDER=ollama: rule-based diagnosis in the engine, Ollama assistant on the dashboard)")
        sys.exit(1 if bad else 0)
    model = [p["ParameterValue"] for p in cf.describe_stacks(StackName=f"{P}-03-engine")["Stacks"][0]["Parameters"] if p["ParameterKey"] == "BedrockModelId"][0]
    rt = boto3.client("bedrock-runtime", region_name=R)
    rt.converse(modelId=model, messages=[{"role": "user", "content": [{"text": "OK?"}]}], inferenceConfig={"maxTokens": 10})
    check("Bedrock model answers", True, model)
except Exception as e:  # noqa: BLE001
    check("Bedrock model answers", False, str(e)[:120])

sys.exit(1 if bad else 0)
