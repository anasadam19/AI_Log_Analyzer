#!/usr/bin/env python3
"""Create a realistic incident to prove the whole pipeline works (needs the demo workload: ENABLE_DEMO=true).

  python3 scripts/inject_incident.py --scenario db_outage --wait       # multi-service cascade, RCA = database connections
  python3 scripts/inject_incident.py --scenario lambda_timeout --wait  # exercises the full REMEDIATION loop (Lambda timeout raised after approval)
Scenarios: db_outage | throttle | iam_denied | memory_leak | lambda_timeout
"""
import argparse
import json
import os
import time

import boto3

PROJECT = os.environ.get("PROJECT", "aiops")
REGION = os.environ.get("AWS_REGION") or os.environ.get("AWS_DEFAULT_REGION") or boto3.session.Session().region_name


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--scenario", default="db_outage", choices=["db_outage", "throttle", "iam_denied", "memory_leak", "lambda_timeout"])
    ap.add_argument("--minutes", type=int, default=8)
    ap.add_argument("--wait", action="store_true", help="poll until the engine reports the incident (up to 12 min)")
    a = ap.parse_args()
    lam = boto3.client("lambda", region_name=REGION)
    ddb = boto3.resource("dynamodb", region_name=REGION).Table(f"{PROJECT}-state")
    t0 = time.time()
    if a.scenario == "lambda_timeout":
        fn = f"{PROJECT}-demo-flaky"
        for _ in range(25):
            lam.invoke(FunctionName=fn, InvocationType="Event", Payload=json.dumps({"work": 3.6}).encode())
        print(f"Invoked {fn} 25x (each runs 3.6 s but its timeout is 3 s) -> 'Task timed out' errors")
    else:
        r = lam.invoke(FunctionName=f"{PROJECT}-sys-demo-logwriter", Payload=json.dumps({"action": "inject", "scenario": a.scenario, "minutes": a.minutes}).encode())
        print("Injected:", json.loads(r["Payload"].read()), f"- the demo writer produces the faulty logs for the next {a.minutes} minutes")
    print("The analyzer runs every 5 minutes. Expect an incident within ~3-8 minutes, then a Bedrock diagnosis, an e-mail, and (for approval mode) a pending approval in the dashboard.")
    if not a.wait:
        return
    from boto3.dynamodb.conditions import Key
    seen = set()
    while time.time() - t0 < 720:
        for it in ddb.query(KeyConditionExpression=Key("pk").eq("INCIDENT"))["Items"]:
            if float(it.get("created_ts", 0)) >= t0 and it["id"] not in seen:
                seen.add(it["id"])
                print(f"\n[{int(time.time() - t0)}s] INCIDENT {it['id']}: {it['title']} severity={it['severity']} runbook={it.get('runbook')}")
        for it in ddb.query(KeyConditionExpression=Key("pk").eq("INCIDENT"))["Items"]:
            if it["id"] in seen and it.get("ai"):
                ai = it["ai"]
                print(f"[{int(time.time() - t0)}s] AI ({ai.get('source')}): {ai.get('summary')}\n   root cause: {ai.get('probable_root_cause')}  confidence: {ai.get('confidence')}  runbook: {ai.get('runbook')}")
                print(f"   remediation_state: {it.get('remediation_state', '-')}")
                return
        print(".", end="", flush=True)
        time.sleep(20)
    print("\nTimed out waiting - check the analyzer logs:  aws logs tail /aws/lambda/%s-sys-analyzer --since 15m" % PROJECT)


if __name__ == "__main__":
    main()
