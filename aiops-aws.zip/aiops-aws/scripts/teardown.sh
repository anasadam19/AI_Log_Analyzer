#!/usr/bin/env bash
# Remove everything this project created.   ./scripts/teardown.sh [--purge-data]
#   --purge-data also EMPTIES and DELETES the S3 archive + artifacts buckets and the users parameter (irreversible).
set -euo pipefail
cd "$(dirname "$0")/.."
PROJECT="${PROJECT:-aiops}"
REGION="${AWS_REGION:-${AWS_DEFAULT_REGION:-$(aws configure get region)}}"
export AWS_REGION="$REGION"
ACCOUNT="$(aws sts get-caller-identity --query Account --output text)"
PURGE="${1:-}"
read -r -p "Delete ALL ${PROJECT}-* stacks in ${REGION} (account ${ACCOUNT})? type 'yes': " ans
[ "$ans" = "yes" ] || exit 1

echo "== Removing log subscription filters created by the onboarder"
PROJECT="$PROJECT" python3 scripts/enable_log_sources.py --remove-subscriptions --apply || true

for s in 04-dashboard 03-engine 02-log-aggregation 01-foundation; do
  echo "== Deleting ${PROJECT}-${s}"
  aws cloudformation delete-stack --stack-name "${PROJECT}-${s}"
  aws cloudformation wait stack-delete-complete --stack-name "${PROJECT}-${s}" || echo "   (check the stack events if this failed)"
done

if [ "$PURGE" = "--purge-data" ]; then
  for b in "${PROJECT}-archive-${ACCOUNT}-${REGION}" "${PROJECT}-artifacts-${ACCOUNT}-${REGION}"; do
    echo "== Purging bucket $b"
    aws s3 rb "s3://$b" --force || true
  done
  aws ssm delete-parameter --name /aiops/dashboard/users 2>/dev/null || true
else
  echo "Kept: S3 archive bucket ${PROJECT}-archive-${ACCOUNT}-${REGION} (DeletionPolicy=Retain) and the artifacts bucket. Use --purge-data to remove them."
fi
echo "Log groups that were auto-created by Lambda/agents (e.g. /aiops/*) may remain; delete them in CloudWatch if unwanted."
