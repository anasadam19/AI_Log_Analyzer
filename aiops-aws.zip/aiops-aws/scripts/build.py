#!/usr/bin/env python3
"""Package Lambda zips and the dashboard tarball into ./build (cross-platform, no external tools)."""
import argparse
import io
import os
import tarfile
import zipfile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
LAMBDAS = ["analyzer", "fixer", "remediator", "onboarder", "demo_logwriter", "demo_flaky"]
SKIP = ("__pycache__", ".pyc", ".DS_Store")


def files(base):
    for dp, dn, fn in os.walk(base):
        dn[:] = [d for d in dn if d not in ("__pycache__", ".pytest_cache", ".streamlit_cache")]
        for f in fn:
            if not f.endswith(SKIP):
                p = os.path.join(dp, f)
                yield p, os.path.relpath(p, base)


def build(out):
    os.makedirs(out, exist_ok=True)
    core = os.path.join(ROOT, "shared", "aiops_core")
    for name in LAMBDAS:
        zp = os.path.join(out, f"{name}.zip")
        with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
            z.write(os.path.join(ROOT, "lambdas", name, "handler.py"), "handler.py")
            for p, rel in files(core):
                z.write(p, os.path.join("aiops_core", rel))
        print(f"  {zp}  ({os.path.getsize(zp) / 1024:.0f} KB)")
    tp = os.path.join(out, "dashboard.tar.gz")
    with tarfile.open(tp, "w:gz") as t:
        for p, rel in files(os.path.join(ROOT, "dashboard")):
            t.add(p, rel)
        for p, rel in files(core):
            t.add(p, os.path.join("aiops_core", rel))
    print(f"  {tp}  ({os.path.getsize(tp) / 1024:.0f} KB)")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(ROOT, "build"))
    build(ap.parse_args().out)
