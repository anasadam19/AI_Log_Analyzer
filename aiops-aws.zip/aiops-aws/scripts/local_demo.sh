#!/usr/bin/env bash
# Try the dashboard on your laptop with synthetic data - NO AWS account needed.
#   ./scripts/local_demo.sh            then open http://localhost:8501   (login: admin / admin)
set -euo pipefail
cd "$(dirname "$0")/.."
python3 -m venv .venv 2>/dev/null || true
# shellcheck disable=SC1091
. .venv/bin/activate 2>/dev/null || . .venv/Scripts/activate
pip install -q -r dashboard/requirements.txt
export AIOPS_BACKEND=local LLM_PROVIDER=mock AIOPS_LOCAL_SCENARIO="${SCENARIO:-db_outage}"   # db_outage | throttle | iam_denied | memory_leak
cd dashboard && streamlit run app.py
