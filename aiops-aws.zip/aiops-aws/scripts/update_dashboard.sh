#!/usr/bin/env bash
# Hot-update the dashboard code on the running instance (no instance replacement, ~20 s).
#   ./scripts/update_dashboard.sh
set -euo pipefail
cd "$(dirname "$0")/.."
PROJECT="${PROJECT:-aiops}"
REGION="${AWS_REGION:-${AWS_DEFAULT_REGION:-$(aws configure get region)}}"
ACCOUNT="$(aws sts get-caller-identity --query Account --output text)"
BUCKET="${PROJECT}-artifacts-${ACCOUNT}-${REGION}"
KEY="hotfix/dashboard-$(date -u +%Y%m%d-%H%M%S).tar.gz"
python3 scripts/build.py --out build >/dev/null
aws s3 cp build/dashboard.tar.gz "s3://${BUCKET}/${KEY}" --only-show-errors
IID="$(aws cloudformation describe-stacks --stack-name "${PROJECT}-04-dashboard" --query "Stacks[0].Outputs[?OutputKey=='InstanceId'].OutputValue" --output text)"
CMD="aws s3 cp s3://${BUCKET}/${KEY} /tmp/d.tgz --region ${REGION} && tar -xzf /tmp/d.tgz -C /opt/aiops && chown -R aiops:aiops /opt/aiops && /opt/aiops/venv/bin/pip install -q -r /opt/aiops/requirements.txt && systemctl restart aiops-dashboard && systemctl is-active aiops-dashboard"
aws ssm send-command --instance-ids "$IID" --document-name AWS-RunShellScript --parameters "commands=[\"$CMD\"]" --query "Command.CommandId" --output text
echo "Update sent to $IID. Follow with: aws ssm list-command-invocations --details --max-items 1"
