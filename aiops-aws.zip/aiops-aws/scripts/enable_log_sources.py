#!/usr/bin/env python3
"""Turn on logging for as many AWS services in this account/region as possible and route it to CloudWatch Logs / S3.

DRY-RUN by default - prints what it would change. Add --apply to make the changes.

  python3 scripts/enable_log_sources.py --all                 # dry run for every source below
  python3 scripts/enable_log_sources.py --all --apply
  python3 scripts/enable_log_sources.py --rds --eks --apply   # pick sources
  python3 scripts/enable_log_sources.py --sweep --apply       # subscribe EVERY log group to the S3 archive + set retention
  python3 scripts/enable_log_sources.py --remove-subscriptions --apply   # used by teardown

Sources: --rds  --eks  --vpc-flow  --alb  --s3-access  --sweep
(API Gateway, ECS/Fargate, Lambda, Step Functions, CodeBuild and others log through their own settings - see docs/LOG_SOURCES.md.)
"""
import argparse
import json
import os
import sys

import boto3
from botocore.exceptions import ClientError

PROJECT = os.environ.get("PROJECT", "aiops")
REGION = os.environ.get("AWS_REGION") or os.environ.get("AWS_DEFAULT_REGION") or boto3.session.Session().region_name
RETENTION = int(os.environ.get("RETENTION_DAYS", "30"))
APPLY = False


def act(msg, fn=None):
    print(("APPLY  " if APPLY else "DRYRUN ") + msg)
    if APPLY and fn:
        try:
            fn()
        except ClientError as e:
            print("   !! " + e.response["Error"]["Message"][:200])


def out(stack, key):
    for o in boto3.client("cloudformation", region_name=REGION).describe_stacks(StackName=stack)["Stacks"][0]["Outputs"]:
        if o["OutputKey"] == key:
            return o["OutputValue"]
    raise KeyError(key)


# ----------------------------------------------------------------------------- RDS / Aurora
WANTED_RDS = {"error", "slowquery", "postgresql", "upgrade", "alert", "listener", "agent"}  # 'general'/'audit' omitted: very noisy/costly


def rds():
    c = boto3.client("rds", region_name=REGION)
    for page in c.get_paginator("describe_db_instances").paginate():
        for db in page["DBInstances"]:
            eng = db["Engine"]
            if db.get("DBClusterIdentifier"):
                continue  # cluster members handled at cluster level
            vers = c.describe_db_engine_versions(Engine=eng, EngineVersion=db["EngineVersion"])["DBEngineVersions"]
            types = set(vers[0].get("ExportableLogTypes", [])) & WANTED_RDS if vers else set()
            todo = sorted(types - set(db.get("EnabledCloudwatchLogsExports", [])))
            if todo:
                act(f"RDS instance {db['DBInstanceIdentifier']} ({eng}): export {todo} to CloudWatch",
                    lambda db=db, todo=todo: c.modify_db_instance(DBInstanceIdentifier=db["DBInstanceIdentifier"], ApplyImmediately=True,
                                                                  CloudwatchLogsExportConfiguration={"EnableLogTypes": todo}))
    for page in c.get_paginator("describe_db_clusters").paginate():
        for cl in page["DBClusters"]:
            vers = c.describe_db_engine_versions(Engine=cl["Engine"], EngineVersion=cl["EngineVersion"])["DBEngineVersions"]
            types = set(vers[0].get("ExportableLogTypes", [])) & WANTED_RDS if vers else set()
            todo = sorted(types - set(cl.get("EnabledCloudwatchLogsExports", [])))
            if todo:
                act(f"Aurora/RDS cluster {cl['DBClusterIdentifier']} ({cl['Engine']}): export {todo}",
                    lambda cl=cl, todo=todo: c.modify_db_cluster(DBClusterIdentifier=cl["DBClusterIdentifier"], ApplyImmediately=True,
                                                                  CloudwatchLogsExportConfiguration={"EnableLogTypes": todo}))


# ----------------------------------------------------------------------------- EKS control plane
def eks():
    c = boto3.client("eks", region_name=REGION)
    want = ["api", "authenticator", "controllerManager", "scheduler"]  # 'audit' is very large; enable manually if you need it
    for name in c.list_clusters()["clusters"]:
        log = c.describe_cluster(name=name)["cluster"].get("logging", {}).get("clusterLogging", [])
        on = {t for e in log if e.get("enabled") for t in e["types"]}
        todo = [t for t in want if t not in on]
        if todo:
            act(f"EKS cluster {name}: enable control-plane logs {todo}",
                lambda name=name, todo=todo: c.update_cluster_config(name=name, logging={"clusterLogging": [{"types": todo, "enabled": True}]}))


# ----------------------------------------------------------------------------- VPC flow logs
def vpc_flow():
    ec2 = boto3.client("ec2", region_name=REGION)
    logs = boto3.client("logs", region_name=REGION)
    role = out(f"{PROJECT}-02-log-aggregation", "FlowLogRoleArn")
    have = {f["ResourceId"] for f in ec2.describe_flow_logs()["FlowLogs"]}
    for v in ec2.describe_vpcs()["Vpcs"]:
        vid = v["VpcId"]
        if vid in have:
            continue
        grp = f"/aws/vpc/flowlogs/{vid}"

        def go(vid=vid, grp=grp):
            try:
                logs.create_log_group(logGroupName=grp)
            except logs.exceptions.ResourceAlreadyExistsException:
                pass
            logs.put_retention_policy(logGroupName=grp, retentionInDays=RETENTION)
            ec2.create_flow_logs(ResourceType="VPC", ResourceIds=[vid], TrafficType="ALL", LogDestinationType="cloud-watch-logs",
                                 LogGroupName=grp, DeliverLogsPermissionArn=role, MaxAggregationInterval=60)
        act(f"VPC {vid}: create flow logs -> {grp}", go)


# ----------------------------------------------------------------------------- ALB access logs -> S3
def alb():
    c = boto3.client("elbv2", region_name=REGION)
    bucket = out(f"{PROJECT}-01-foundation", "ArchiveBucketName")
    for page in c.get_paginator("describe_load_balancers").paginate():
        for lb in page["LoadBalancers"]:
            attrs = {a["Key"]: a["Value"] for a in c.describe_load_balancer_attributes(LoadBalancerArn=lb["LoadBalancerArn"])["Attributes"]}
            if attrs.get("access_logs.s3.enabled") == "true":
                continue
            act(f"{lb['Type']} load balancer {lb['LoadBalancerName']}: access logs -> s3://{bucket}/alb/",
                lambda lb=lb: c.modify_load_balancer_attributes(LoadBalancerArn=lb["LoadBalancerArn"], Attributes=[
                    {"Key": "access_logs.s3.enabled", "Value": "true"}, {"Key": "access_logs.s3.bucket", "Value": bucket},
                    {"Key": "access_logs.s3.prefix", "Value": "alb"}]))


# ----------------------------------------------------------------------------- S3 server access logs -> S3
def s3_access():
    s3 = boto3.client("s3", region_name=REGION)
    target = out(f"{PROJECT}-01-foundation", "ArchiveBucketName")
    for b in s3.list_buckets()["Buckets"]:
        n = b["Name"]
        if n == target or n.startswith(f"{PROJECT}-"):
            continue
        try:
            loc = s3.get_bucket_location(Bucket=n)["LocationConstraint"] or "us-east-1"
            if loc != REGION:
                continue
            if s3.get_bucket_logging(Bucket=n).get("LoggingEnabled"):
                continue
        except ClientError:
            continue
        act(f"S3 bucket {n}: server access logs -> s3://{target}/s3-access/{n}/",
            lambda n=n: s3.put_bucket_logging(Bucket=n, BucketLoggingStatus={"LoggingEnabled": {"TargetBucket": target, "TargetPrefix": f"s3-access/{n}/"}}))


# ----------------------------------------------------------------------------- onboarding / cleanup
def sweep():
    fn = f"{PROJECT}-sys-onboarder"
    try:
        boto3.client("lambda", region_name=REGION).get_function(FunctionName=fn)
    except ClientError:
        print("SKIP   onboarder Lambda not found (archive disabled / lean mode)")
        return
    act(f"invoke {fn} {{sweep:true}}: subscribe every log group to the S3 archive and set {RETENTION}-day retention",
        lambda: print("   ->", json.loads(boto3.client("lambda", region_name=REGION).invoke(FunctionName=fn, Payload=b'{"sweep":true}')["Payload"].read()).get("subscribed"), "newly subscribed"))


def remove_subscriptions():
    logs = boto3.client("logs", region_name=REGION)
    for page in logs.get_paginator("describe_log_groups").paginate():
        for g in page["logGroups"]:
            for f in logs.describe_subscription_filters(logGroupName=g["logGroupName"])["subscriptionFilters"]:
                if f["filterName"] == "aiops-archive":
                    act(f"remove subscription filter from {g['logGroupName']}",
                        lambda g=g: logs.delete_subscription_filter(logGroupName=g["logGroupName"], filterName="aiops-archive"))


def main():
    global APPLY
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    for f in ("rds", "eks", "vpc-flow", "alb", "s3-access", "sweep", "remove-subscriptions", "all", "apply"):
        ap.add_argument(f"--{f}", action="store_true")
    a = ap.parse_args()
    APPLY = a.apply
    steps = [("rds", rds), ("eks", eks), ("vpc_flow", vpc_flow), ("alb", alb), ("s3_access", s3_access), ("sweep", sweep)]
    ran = False
    for name, fn in steps:
        if a.all or getattr(a, name):
            print(f"\n--- {name}")
            fn()
            ran = True
    if a.remove_subscriptions:
        remove_subscriptions()
        ran = True
    if not ran:
        ap.print_help()
        sys.exit(1)
    if not APPLY:
        print("\n(dry run - nothing changed. Re-run with --apply)")


if __name__ == "__main__":
    main()
