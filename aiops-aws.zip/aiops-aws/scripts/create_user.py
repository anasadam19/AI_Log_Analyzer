#!/usr/bin/env python3
"""Create / update / delete a dashboard user. Passwords are bcrypt-hashed locally; only the hash is stored (SSM SecureString).

  python3 scripts/create_user.py --username admin --role admin
  python3 scripts/create_user.py --username alice --role operator
  python3 scripts/create_user.py --username bob --role viewer
  python3 scripts/create_user.py --username bob --delete
Roles: viewer (read-only) | operator (ack/resolve, run analysis, AI assistant) | admin (also approve remediation)
Requires:  pip install bcrypt boto3
"""
import argparse
import getpass
import json
import os
import sys

import bcrypt
import boto3


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--username", required=True)
    ap.add_argument("--role", choices=["viewer", "operator", "admin"], default="viewer")
    ap.add_argument("--delete", action="store_true")
    ap.add_argument("--param", default=os.environ.get("USERS_PARAM", "/aiops/dashboard/users"))
    ap.add_argument("--region", default=os.environ.get("AWS_REGION") or os.environ.get("AWS_DEFAULT_REGION"))
    a = ap.parse_args()
    ssm = boto3.client("ssm", region_name=a.region)
    try:
        users = json.loads(ssm.get_parameter(Name=a.param, WithDecryption=True)["Parameter"]["Value"])
    except ssm.exceptions.ParameterNotFound:
        users = {}
    if a.delete:
        users.pop(a.username, None)
        print(f"deleted {a.username}")
    else:
        pw = getpass.getpass("Password (min 12 chars): ")
        if len(pw) < 12:
            sys.exit("Password too short (min 12).")
        if pw != getpass.getpass("Repeat password: "):
            sys.exit("Passwords differ.")
        users[a.username] = {"hash": bcrypt.hashpw(pw.encode(), bcrypt.gensalt(12)).decode(), "role": a.role}
        print(f"saved {a.username} ({a.role})")
    ssm.put_parameter(Name=a.param, Value=json.dumps(users), Type="SecureString", Overwrite=True, Tier="Standard",
                      Description="AIOps dashboard users (bcrypt hashes)")
    print("Users now:", ", ".join(f"{u}({v['role']})" for u, v in users.items()) or "(none)")
    print("The dashboard refreshes its user list every 60 s - no restart needed.")


if __name__ == "__main__":
    main()
