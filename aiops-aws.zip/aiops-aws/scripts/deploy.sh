#!/usr/bin/env bash
# One-command deployment of the whole platform.   Run from the repo root (AWS CloudShell works great).
#
#   ALERT_EMAIL=you@example.com ./scripts/deploy.sh            # everything
#   ./scripts/deploy.sh 3                                      # only stack 3 (engine) - re-packages code too
#
# Optional environment variables:
#   PROJECT=aiops  AWS_REGION=ap-south-1  ALLOWED_CIDR=1.2.3.4/32  CERT_ARN=arn:aws:acm:...
#   BEDROCK_REGION=us-east-1 (only if Bedrock models are not available in your main region)  BEDROCK_MODEL_ID=...  REMEDIATION_MODE=approval|suggest|auto  ENABLE_DEMO=true|false  ENABLE_CLOUDTRAIL=true|false
#   SLACK_WEBHOOK_URL=https://hooks.slack.com/...
set -euo pipefail
cd "$(dirname "$0")/.."

PROJECT="${PROJECT:-aiops}"
REGION="${AWS_REGION:-${AWS_DEFAULT_REGION:-$(aws configure get region 2>/dev/null || true)}}"
[ -n "$REGION" ] || { echo "Set AWS_REGION (e.g. export AWS_REGION=ap-south-1)"; exit 1; }
export AWS_REGION="$REGION" AWS_DEFAULT_REGION="$REGION"
ACCOUNT="$(aws sts get-caller-identity --query Account --output text)"
STEP="${1:-all}"
ALERT_EMAIL="${ALERT_EMAIL:-}"
REMEDIATION_MODE="${REMEDIATION_MODE:-approval}"
ENABLE_DEMO="${ENABLE_DEMO:-true}"
ENABLE_CLOUDTRAIL="${ENABLE_CLOUDTRAIL:-true}"
CERT_ARN="${CERT_ARN:-}"
LLM_PROVIDER="${LLM_PROVIDER:-ollama}"      # ollama (free, runs on the dashboard EC2) | bedrock
OLLAMA_MODEL="${OLLAMA_MODEL:-llama3.2}"
INSTANCE_TYPE="${INSTANCE_TYPE:-t3.large}"
if [ "$LLM_PROVIDER" = "bedrock" ]; then ENGINE_LLM=bedrock; else ENGINE_LLM=none; fi
ART_BUCKET="${PROJECT}-artifacts-${ACCOUNT}-${REGION}"
CAPS="--capabilities CAPABILITY_NAMED_IAM --no-fail-on-empty-changeset"

echo "== Account $ACCOUNT  Region $REGION  Project $PROJECT  Step $STEP"

# ---------------------------------------------------------------- artifacts bucket + packaging
if ! aws s3api head-bucket --bucket "$ART_BUCKET" 2>/dev/null; then
  echo "== Creating artifacts bucket $ART_BUCKET"
  if [ "$REGION" = "us-east-1" ]; then aws s3api create-bucket --bucket "$ART_BUCKET" >/dev/null
  else aws s3api create-bucket --bucket "$ART_BUCKET" --create-bucket-configuration LocationConstraint="$REGION" >/dev/null; fi
  aws s3api put-public-access-block --bucket "$ART_BUCKET" --public-access-block-configuration BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true
  aws s3api put-bucket-encryption --bucket "$ART_BUCKET" --server-side-encryption-configuration '{"Rules":[{"ApplyServerSideEncryptionByDefault":{"SSEAlgorithm":"AES256"}}]}'
fi
VERSION="$(date -u +%Y%m%d-%H%M%S)"
PREFIX="artifacts/${VERSION}/"
echo "== Packaging code -> s3://$ART_BUCKET/$PREFIX"
python3 scripts/build.py --out build
aws s3 cp build/ "s3://$ART_BUCKET/$PREFIX" --recursive --only-show-errors

deploy() { # name template params...
  local name="$1" tpl="$2"; shift 2
  echo "== Deploying stack ${PROJECT}-${name}"
  aws cloudformation deploy --stack-name "${PROJECT}-${name}" --template-file "$tpl" $CAPS --parameter-overrides "ProjectName=$PROJECT" "$@"
}

run() { [ "$STEP" = "all" ] || [ "$STEP" = "$1" ]; }

if run 1; then
  deploy 01-foundation infra/01-foundation.yaml "AlertEmail=$ALERT_EMAIL"
fi

if run 2; then
  deploy 02-log-aggregation infra/02-log-aggregation.yaml "ArtifactBucket=$ART_BUCKET" "ArtifactPrefix=$PREFIX" "EnableCloudTrail=$ENABLE_CLOUDTRAIL"
  echo "== Onboarding existing log groups (archive to S3 + retention)"
  aws lambda invoke --function-name "${PROJECT}-sys-onboarder" --cli-binary-format raw-in-base64-out --payload '{"sweep":true}' /tmp/sweep.json >/dev/null
  python3 -c "import json;d=json.load(open('/tmp/sweep.json'));print('   swept',d.get('sweep'),'groups, newly subscribed:',d.get('subscribed'))"
fi

if run 3; then
  if [ "$LLM_PROVIDER" != "bedrock" ]; then
    BEDROCK_MODEL_ID="${BEDROCK_MODEL_ID:-unused}"
    echo "== LLM_PROVIDER=$LLM_PROVIDER: skipping Bedrock (incident diagnosis is rule-based; the dashboard assistant uses $LLM_PROVIDER)"
  elif [ -z "${BEDROCK_MODEL_ID:-}" ]; then
    echo "== Looking for a Bedrock model that works in $REGION"
    BEDROCK_MODEL_ID="$(python3 scripts/bedrock_check.py)" || { echo "!! Fix Bedrock access first (see messages above), then re-run: ./scripts/deploy.sh 3"; exit 1; }
  fi
  echo "== Using Bedrock model: $BEDROCK_MODEL_ID"
  deploy 03-engine infra/03-engine.yaml "ArtifactBucket=$ART_BUCKET" "ArtifactPrefix=$PREFIX" "BedrockModelId=$BEDROCK_MODEL_ID" \
    "RemediationMode=$REMEDIATION_MODE" "EnableDemo=$ENABLE_DEMO" "SlackWebhookUrl=${SLACK_WEBHOOK_URL:-}" "BedrockRegion=${BEDROCK_REGION:-}" "LlmProvider=$ENGINE_LLM"
fi

if run 4; then
  if [ -z "${ALLOWED_CIDR:-}" ]; then
    MYIP="$(curl -s https://checkip.amazonaws.com | tr -d '[:space:]')"
    ALLOWED_CIDR="${MYIP}/32"
    echo "== ALLOWED_CIDR not set - using your current public IP: $ALLOWED_CIDR"
    echo "   (from AWS CloudShell this is CloudShell's IP, not your laptop's - set ALLOWED_CIDR explicitly!)"
  fi
  [ -n "$CERT_ARN" ] || echo "!! No CERT_ARN: the dashboard will be served over plain HTTP. Use HTTPS for anything beyond a quick test."
  [ -n "${BEDROCK_MODEL_ID:-}" ] || BEDROCK_MODEL_ID="$(aws cloudformation describe-stacks --stack-name "${PROJECT}-03-engine" --query "Stacks[0].Parameters[?ParameterKey=='BedrockModelId'].ParameterValue" --output text)"
  deploy 04-dashboard infra/04-dashboard.yaml "ArtifactBucket=$ART_BUCKET" "DashboardKey=${PREFIX}dashboard.tar.gz" "AllowedCidr=$ALLOWED_CIDR" \
    "CertificateArn=$CERT_ARN" "BedrockModelId=$BEDROCK_MODEL_ID" "BedrockRegion=${BEDROCK_REGION:-}" \
    "LlmProvider=$LLM_PROVIDER" "OllamaModel=$OLLAMA_MODEL" "InstanceType=$INSTANCE_TYPE"
  echo
  aws cloudformation describe-stacks --stack-name "${PROJECT}-04-dashboard" --query "Stacks[0].Outputs[].[OutputKey,OutputValue]" --output table
  echo "NEXT: create a login ->  python3 scripts/create_user.py --username admin --role admin"
fi
echo "== Done."
