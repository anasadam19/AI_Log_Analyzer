import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "shared"))
from aiops_core import *
from aiops_core.simulate import generate
from aiops_core.llm import extract_json, build_fix_prompt
from aiops_core.events import parse_event

NOW = 1_800_000_000.0

def run(scn, minutes=90):
    rows = generate(NOW, minutes=minutes, seed=42, scenario=scn)
    ev = [parse_event(*r) for r in rows]
    an = detect_anomalies(ev, since=NOW - 10 * 60)
    inc = build_incidents(an, ev)
    return ev, an, inc

def test_baseline_has_no_incident():
    ev, an, inc = run(None)
    assert not inc, [i["title"] for i in inc]

def test_db_outage_found_and_root_cause():
    ev, an, inc = run("db_outage")
    assert len(inc) == 1
    i = inc[0]
    assert i["category_id"] == "db_conn"
    assert i["root_service"] == "demo:payments-db"
    assert i["severity"] in ("high", "critical")
    assert len(i["services"]) >= 3

def test_other_scenarios():
    for scn, cid in [("throttle", "throttle"), ("iam_denied", "iam_denied"), ("memory_leak", "memory")]:
        _, _, inc = run(scn)
        assert inc and inc[0]["category_id"] == cid, (scn, [x["title"] for x in inc])

def test_signature_order_lock_before_timeout():
    assert classify("ERROR Lock wait timeout exceeded; try restarting transaction")["id"] == "db_lock"
    assert classify("Task timed out after 3.00 seconds")["id"] == "lambda_timeout"
    assert classify("random thing")["id"] == "unknown"

def test_parsers():
    e = parse_event("/aws/lambda/foo", "s", 1000, "2026-01-01T00:00:00Z\tabc\tTask timed out after 3.00 seconds")
    assert e.level == "ERROR" and e.service == "lambda:foo"
    e = parse_event("/aws/lambda/foo", "s", 1000, "REPORT RequestId: x Duration: 123.45 ms Billed Duration: 124 ms")
    assert e.latency_ms == 123.45 and e.level == "INFO"
    e = parse_event("/aws/cloudtrail/x", "s", 1000, '{"eventSource":"s3.amazonaws.com","eventName":"GetObject","errorCode":"AccessDenied"}')
    assert e.level == "WARN" and "security" in e.tags
    e = parse_event("/aws/events/x", "s", 1000, '{"source":"aws.guardduty","detail-type":"GuardDuty Finding","detail":{"severity":8.1,"type":"Recon"}}')
    assert e.level == "CRITICAL"
    e = parse_event("/aiops/app/dash", "i-0123456789abcdef0", 1000, "[ERROR] boom")
    assert e.level == "ERROR" and instance_from_stream(e.stream) == "i-0123456789abcdef0"

def test_patterns_compression_and_risk():
    ev, an, inc = run("db_outage")
    pats = mine_patterns(ev, 20)
    assert len(pats) < len(ev) / 20
    risk = risk_scores(ev, NOW)
    assert risk[0]["risk"] > 40

def test_redact_and_json():
    r = redact("user a@b.com key AKIAABCDEFGHIJKLMNOP password=hunter22 from 10.1.2.3 arn:aws:iam::123456789012:role/x")
    assert "a@b.com" not in r and "AKIA" not in r and "hunter22" not in r and "10.1.2.3" not in r and "123456789012" not in r
    assert extract_json('Sure!\n```json\n{"a": {"b": "}"}}\n```')["a"]["b"] == "}"

def test_prompt_builds():
    _, _, inc = run("db_outage")
    p = build_fix_prompt(inc[0])
    assert "db_conn" not in p and "payments-db" in p and "runbook" in p

def test_archive_parser_firehose_concat_and_cloudtrail():
    import gzip, json
    from aiops_core.archive import parse_archive_blob
    def batch(g, msgs):
        return gzip.compress(json.dumps({"messageType": "DATA_MESSAGE", "logGroup": g, "logStream": "i-0123456789abcdef0",
                                         "logEvents": [{"id": str(i), "timestamp": 1_800_000_000_000 + i, "message": m} for i, m in enumerate(msgs)]}).encode())
    blob = batch("/aws/lambda/foo", ["Task timed out after 3.00 seconds", "ok"]) + batch("/aws/rds/instance/db1/postgresql", ["FATAL: too many connections"]) \
        + gzip.compress(json.dumps({"messageType": "CONTROL_MESSAGE", "logEvents": []}).encode())
    ev = parse_archive_blob(blob)
    assert [e.service for e in ev] == ["lambda:foo", "lambda:foo", "rds:db1"] and ev[0].level == "ERROR"
    ct = gzip.compress(json.dumps({"Records": [{"eventTime": "2026-01-01T00:00:00Z", "eventSource": "s3.amazonaws.com", "eventName": "GetObject", "errorCode": "AccessDenied"}]}).encode())
    e = parse_archive_blob(ct)[0]
    assert e.level == "WARN" and "security" in e.tags
