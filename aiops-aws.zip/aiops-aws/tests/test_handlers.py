import importlib.util, io, json, os, sys, time, zipfile
import pytest
ROOT = os.path.join(os.path.dirname(__file__), "..")
sys.path.insert(0, os.path.join(ROOT, "shared"))
os.environ.update(AWS_DEFAULT_REGION="us-east-1", AWS_ACCESS_KEY_ID="x", AWS_SECRET_ACCESS_KEY="x", STATE_TABLE="aiops-state",
                  AWS_REGION="us-east-1", LOG_GROUP_PREFIXES="/aiops/demo/", EXCLUDE_PREFIXES="/aws/lambda/aiops-sys-",
                  AUDIT_LOG_GROUP="/aiops/audit", REMEDIATION_MODE="approval")
import boto3
from moto import mock_aws
from aiops_core.simulate import generate, SERVICES

def load(name):
    spec = importlib.util.spec_from_file_location(f"h_{name}", os.path.join(ROOT, "lambdas", name, "handler.py"))
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m

def make_table():
    d = boto3.resource("dynamodb")
    d.create_table(TableName="aiops-state", KeySchema=[{"AttributeName": "pk", "KeyType": "HASH"}, {"AttributeName": "sk", "KeyType": "RANGE"}],
                   AttributeDefinitions=[{"AttributeName": "pk", "AttributeType": "S"}, {"AttributeName": "sk", "AttributeType": "S"}], BillingMode="PAY_PER_REQUEST")
    return d.Table("aiops-state")

def seed_logs(scenario):
    l = boto3.client("logs")
    rows = generate(time.time() - 5, minutes=70, seed=1, scenario=scenario)
    by = {}
    for g, s, ts, m in rows:
        by.setdefault((g, s), []).append(dict(timestamp=ts, message=m))
    for (g, s), ev in by.items():
        l.create_log_group(logGroupName=g); l.create_log_stream(logGroupName=g, logStreamName=s)
        for i in range(0, len(ev), 500):
            l.put_log_events(logGroupName=g, logStreamName=s, logEvents=ev[i:i+500])

@mock_aws
def test_analyzer_end_to_end():
    tbl = make_table(); seed_logs("db_outage")
    a = load("analyzer")
    res = a.lambda_handler({}, None)
    assert res["groups"] == len(SERVICES) and res["incidents"] >= 1
    inc = tbl.get_item(Key={"pk": "INCIDENT", "sk": res["new"][0]})["Item"]
    assert inc["category_id"] == "db_conn" and inc["root_service"] == "demo:payments-db"
    assert tbl.get_item(Key={"pk": "SNAPSHOT", "sk": "latest"})["Item"]["events"] > 100
    # second run must extend, not duplicate
    res2 = a.lambda_handler({}, None)
    assert res2["new"] == []
    n = tbl.query(KeyConditionExpression=boto3.dynamodb.conditions.Key("pk").eq("INCIDENT"))["Count"]
    assert n == len(res["new"])
    m = boto3.client("cloudwatch").list_metrics(Namespace="AIOps")["Metrics"]
    assert any(x["MetricName"] == "HighSeverityIncidents" for x in m)

@mock_aws
def test_fixer_bedrock_and_fallback(monkeypatch):
    tbl = make_table(); seed_logs("db_outage")
    a = load("analyzer"); iid = a.lambda_handler({}, None)["new"][0]
    f = load("fixer")
    good = {"summary": "DB out of connections", "probable_root_cause": "payments-db max_connections", "confidence": 0.9,
            "evidence": ["x"], "recommended_actions": [{"step": "s", "how": "h", "risk": "low"}], "runbook": "rm -rf /", "prevention": []}
    monkeypatch.setattr(f, "converse", lambda *a, **k: dict(text="```json\n" + json.dumps(good) + "\n```", input_tokens=10, output_tokens=5, model="m"))
    monkeypatch.setattr(f, "publish", lambda *a, **k: True)
    out = f.lambda_handler({"incident_id": iid}, None)
    it = tbl.get_item(Key={"pk": "INCIDENT", "sk": iid})["Item"]
    assert out["source"] == "bedrock" and it["ai"]["probable_root_cause"].startswith("payments-db")
    assert out["runbook"] == "none"          # hostile/unknown runbook suggestion is dropped
    from aiops_core.llm import LLMError
    def boom(*a, **k): raise LLMError("denied")
    monkeypatch.setattr(f, "converse", boom)
    out = f.lambda_handler({"incident_id": iid}, None)
    assert out["source"] == "rule-based"

def _zip():
    b = io.BytesIO()
    with zipfile.ZipFile(b, "w") as z: z.writestr("h.py", "def handler(e,c): return 1")
    return b.getvalue()

@mock_aws
def test_remediator_flow(monkeypatch):
    tbl = make_table()
    boto3.client("logs").create_log_group(logGroupName="/aiops/audit")
    iam = boto3.client("iam")
    role = iam.create_role(RoleName="r", AssumeRolePolicyDocument="{}")["Role"]["Arn"]
    lam = boto3.client("lambda")
    for name, tagged in (("aiops-demo-flaky", "true"), ("other-fn", "false")):
        lam.create_function(FunctionName=name, Runtime="python3.12", Role=role, Handler="h.handler", Code={"ZipFile": _zip()},
                            Timeout=3, MemorySize=128, Tags={"AIOpsManaged": tagged})
    r = load("remediator")
    base = dict(pk="INCIDENT", sk="abc", id="abc", title="Lambda timeout", status="open", severity="high", category_id="lambda_timeout",
                runbook="lambda_scale_config", targets={"lambda": ["aiops-demo-flaky", "other-fn", "aiops-sys-analyzer"], "instances": []},
                start_ts=1, end_ts=2, services={}, samples=[])
    tbl.put_item(Item=base)
    monkeypatch.setattr(r, "publish", lambda *a, **k: True)
    # alarm -> approval mode only marks pending
    ev = {"detail-type": "CloudWatch Alarm State Change", "detail": {"alarmName": "aiops-high", "state": {"value": "ALARM"}}}
    out = r.lambda_handler(ev, None)
    assert out["handled"] == [("abc", "pending_approval")] or out["handled"] == [["abc", "pending_approval"]]
    assert lam.get_function_configuration(FunctionName="aiops-demo-flaky")["Timeout"] == 3
    # approval executes
    res = r.lambda_handler({"action": "execute", "incident_id": "abc", "approved_by": "alice"}, None)
    st = {x["target"]: x["status"] for x in res["results"]}
    assert st["aiops-demo-flaky"] == "applied" and st["other-fn"] == "skipped" and st["aiops-sys-analyzer"] == "skipped"
    assert lam.get_function_configuration(FunctionName="aiops-demo-flaky")["Timeout"] == 5
    # cool-down prevents a second change
    res = r.lambda_handler({"action": "execute", "incident_id": "abc", "approved_by": "alice"}, None)
    assert {x["target"]: x["status"] for x in res["results"]}["aiops-demo-flaky"] == "skipped"
    # LLM-chosen / unknown runbook is rejected
    tbl.update_item(Key={"pk": "INCIDENT", "sk": "abc"}, UpdateExpression="SET runbook=:r", ExpressionAttributeValues={":r": "drop_database"})
    assert r.lambda_handler({"action": "execute", "incident_id": "abc", "approved_by": "bob"}, None)["status"] == "rejected"

@mock_aws
def test_onboarder_subscribes_and_excludes():
    l = boto3.client("logs")
    for g in ("/aws/lambda/foo", "/aws/lambda/aiops-sys-analyzer"): l.create_log_group(logGroupName=g)
    boto3.client("s3").create_bucket(Bucket="arch")
    role = boto3.client("iam").create_role(RoleName="fh", AssumeRolePolicyDocument="{}")["Role"]["Arn"]
    fh = boto3.client("firehose").create_delivery_stream(DeliveryStreamName="x", ExtendedS3DestinationConfiguration=dict(RoleARN=role, BucketARN="arn:aws:s3:::arch"))
    os.environ.update(FIREHOSE_ARN=fh["DeliveryStreamARN"], CWL_TO_FIREHOSE_ROLE_ARN=role)
    o = load("onboarder")
    assert o.onboard("/aws/lambda/aiops-sys-analyzer") == "excluded"
    assert o.onboard("/aws/lambda/foo") in ("subscribed", "already")
    assert l.describe_log_groups(logGroupNamePrefix="/aws/lambda/foo")["logGroups"][0]["retentionInDays"] == 30
