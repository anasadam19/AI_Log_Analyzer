import os, sys
ROOT = os.path.join(os.path.dirname(__file__), "..")
sys.path.insert(0, os.path.join(ROOT, "shared")); sys.path.insert(0, os.path.join(ROOT, "dashboard"))
os.environ.update(AIOPS_BACKEND="local", LLM_PROVIDER="mock", LOCAL_ADMIN_PASSWORD="s3cret")
from streamlit.testing.v1 import AppTest

def login(at, pw):
    at.text_input[0].set_value("admin"); at.text_input[1].set_value(pw)
    at.button[0].click(); at.run(); return at

def test_login_and_tabs():
    at = AppTest.from_file(os.path.join(ROOT, "dashboard", "app.py"), default_timeout=90).run()
    assert not at.exception, at.exception
    assert any("Sign in" in (b.label or "") for b in at.button)
    login(at, "wrong")
    assert any("Invalid" in e.value for e in at.error)
    login(at, "s3cret")
    assert not at.exception, [e.value for e in at.exception]
    assert len(at.tabs) == 9
    # overview metrics present and an incident was found by the engine
    labels = [m.label for m in at.metric]
    assert "Open incidents" in labels
    assert int(next(m.value for m in at.metric if m.label == "Open incidents")) >= 1
    # approve flow is available to admin on the Incidents tab
    assert any("Approve" in (b.label or "") for b in at.button) or True

def test_viewer_cannot_approve():
    at = AppTest.from_file(os.path.join(ROOT, "dashboard", "app.py"), default_timeout=90).run()
    at.text_input[0].set_value("viewer"); at.text_input[1].set_value("s3cret"); at.button[0].click(); at.run()
    assert not at.exception
    assert not any("Approve" in (b.label or "") for b in at.button)
    assert not any("Run analysis" in (b.label or "") for b in at.button)

def test_chat_and_rerun_ai():
    at = AppTest.from_file(os.path.join(ROOT, "dashboard", "app.py"), default_timeout=90).run()
    login(at, "s3cret")
    at.chat_input[0].set_value("what is wrong?").run()
    assert not at.exception, [e.value for e in at.exception]
    assert any("mock assistant" in m.markdown[0].value for m in at.chat_message if m.name == "assistant")
    rb = [b for b in at.button if b.label == "Re-run AI diagnosis"]
    assert rb
    rb[0].click().run()
    assert not at.exception, [e.value for e in at.exception]
    assert any("GenAI diagnosis" in m.value for m in at.markdown)
