# AIOps Platform on AWS

Log aggregation (CloudWatch Logs + S3) → AI/ML analysis in Lambda (anomaly detection, pattern mining, root-cause analysis) → **Amazon Bedrock** fix engine → CloudWatch Alarms → EventBridge → guard-railed remediation (Lambda + SSM Automation) → SNS alerts, with a Streamlit dashboard on its own EC2 behind an ALB.

```
aiops-aws/
├── infra/                 4 CloudFormation stacks (foundation, log aggregation, engine, dashboard)
├── lambdas/               analyzer · fixer (Bedrock) · remediator · onboarder · demo workload
├── shared/aiops_core/     parsing, anomaly detection, patterns, RCA, correlation, LLM client, archive reader
├── dashboard/             Streamlit app (login, 9 tabs, Bedrock assistant, approvals)
├── scripts/               deploy · create_user · enable_log_sources · inject_incident · verify · update · teardown · local_demo
├── tests/                 unit + moto + UI tests (pytest)
└── docs/                  GUIDE.md (start here) · LOG_SOURCES.md · ARCHITECTURE.md
```

## Quick start
```bash
# in AWS CloudShell, same region you will use
unzip aiops-aws.zip && cd aiops-aws
export AWS_REGION=ap-south-1 ALERT_EMAIL=you@example.com ALLOWED_CIDR=<your-ip>/32
./scripts/deploy.sh                                        # ~20 min
python3 scripts/create_user.py --username admin --role admin
python3 scripts/inject_incident.py --scenario db_outage --wait
```
Full walkthrough: **docs/GUIDE.md**.

## Try the dashboard without AWS
```bash
./scripts/local_demo.sh        # http://localhost:8501  (admin / admin) – synthetic logs, mock LLM
```

## Run the tests
```bash
pip install -r dashboard/requirements.txt moto[all] pytest cfn-lint
python3 -m pytest -q tests && cfn-lint infra/*.yaml
```
