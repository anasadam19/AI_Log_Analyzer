"""Demo workload: writes realistic multi-service logs to /aiops/demo/<service> every minute.

Inject an incident with  {"action": "inject", "scenario": "db_outage", "minutes": 8}  (scripts/inject_incident.py).
"""
import os
import random
import time

import boto3

from aiops_core import to_ddb
from aiops_core.simulate import SERVICES, SCENARIOS, lines_for

logs = boto3.client("logs")
table = boto3.resource("dynamodb").Table(os.environ["STATE_TABLE"])


def _put(group, stream, lines, now_ms):
    try:
        logs.create_log_stream(logGroupName=group, logStreamName=stream)
    except logs.exceptions.ResourceAlreadyExistsException:
        pass
    events = [dict(timestamp=now_ms - (len(lines) - i) * 20, message=m) for i, m in enumerate(lines)]
    logs.put_log_events(logGroupName=group, logStreamName=stream, logEvents=events)


def lambda_handler(event, context):
    now = time.time()
    if event.get("action") == "inject":
        sc = event.get("scenario", "db_outage")
        if sc not in SCENARIOS:
            return {"error": f"scenario must be one of {SCENARIOS}"}
        mins = int(event.get("minutes", 8))
        table.put_item(Item=to_ddb(dict(pk="DEMO", sk="scenario", scenario=sc, started=now, until=now + mins * 60, expires_at=int(now + mins * 60 + 3600))))
        return {"injected": sc, "minutes": mins}
    st = table.get_item(Key={"pk": "DEMO", "sk": "scenario"}).get("Item")
    scenario, phase = None, 0.0
    if st and float(st["until"]) > now:
        scenario = st["scenario"]
        phase = (now - float(st["started"])) / max(1.0, float(st["until"]) - float(st["started"]))
    rng = random.Random()
    day = time.strftime("%Y-%m-%d", time.gmtime())
    for svc in SERVICES:
        _put(f"/aiops/demo/{svc}", f"i-0demo{day.replace('-', '')}", lines_for(svc, rng, scenario, phase), int(now * 1000))
    return {"scenario": scenario, "phase": round(phase, 2)}
