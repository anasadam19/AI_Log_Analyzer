"""Log-group onboarding: makes sure EVERY CloudWatch log group is archived to S3 (via Firehose) and has a retention policy.

Invoked
  * by EventBridge when a CloudTrail 'CreateLogGroup' API call is seen (new groups are onboarded automatically)
  * manually with {"sweep": true} to onboard all existing groups (deploy.sh does this once)
"""
import logging
import os

import boto3

from aiops_core import env_list

log = logging.getLogger()
log.setLevel(logging.INFO)
logs = boto3.client("logs")

DEST = os.environ["FIREHOSE_ARN"]
ROLE = os.environ["CWL_TO_FIREHOSE_ROLE_ARN"]
RETENTION = int(os.environ.get("RETENTION_DAYS", "30"))
FILTER_NAME = "aiops-archive"
# never subscribe our own pipeline / audit / firehose logs (avoids feedback loops and cost)
EXCLUDE = env_list(os.environ.get("EXCLUDE_PREFIXES", "/aws/lambda/aiops-sys-,/aws/kinesisfirehose/,/aiops/audit"))


def onboard(name):
    if any(name.startswith(p) for p in EXCLUDE):
        return "excluded"
    g = next((x for x in logs.describe_log_groups(logGroupNamePrefix=name, limit=5)["logGroups"] if x["logGroupName"] == name), None)
    if g is None:
        return "not-found"
    if "retentionInDays" not in g:
        logs.put_retention_policy(logGroupName=name, retentionInDays=RETENTION)
    existing = logs.describe_subscription_filters(logGroupName=name)["subscriptionFilters"]
    if any(f["filterName"] == FILTER_NAME for f in existing):
        return "already"
    if len(existing) >= 2:
        return "limit-2-filters-reached"
    logs.put_subscription_filter(logGroupName=name, filterName=FILTER_NAME, filterPattern="", destinationArn=DEST, roleArn=ROLE)
    return "subscribed"


def lambda_handler(event, context):
    if event.get("sweep"):
        res = {}
        for page in logs.get_paginator("describe_log_groups").paginate():
            for g in page["logGroups"]:
                try:
                    res[g["logGroupName"]] = onboard(g["logGroupName"])
                except Exception as e:  # noqa: BLE001
                    res[g["logGroupName"]] = f"error: {str(e)[:120]}"
        log.info("sweep: %s", res)
        return {"sweep": len(res), "subscribed": sum(1 for v in res.values() if v == "subscribed"), "results": res}
    name = (event.get("detail", {}).get("requestParameters") or {}).get("logGroupName")
    if not name:
        return {"ignored": True}
    # the group may not be visible for a second after CreateLogGroup
    for _ in range(3):
        r = onboard(name)
        if r != "not-found":
            break
        import time
        time.sleep(2)
    log.info("%s -> %s", name, r)
    return {name: r}
