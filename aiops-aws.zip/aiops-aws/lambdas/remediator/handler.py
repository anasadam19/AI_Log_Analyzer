"""Automated remediation (Lambda + SSM Automation) with guard-rails.

Triggers
  * EventBridge: a CloudWatch alarm of this project went to ALARM  -> evaluate open incidents
  * Direct invoke from the dashboard: {"action": "execute", "incident_id": "...", "approved_by": "alice"}

Guard-rails
  * Only runbooks in the allow-list below can ever run - the LLM can merely *suggest* one.
  * REMEDIATION_MODE: suggest (notify only) | approval (default; a human approves in the dashboard) | auto (only AUTO_RUNBOOKS)
  * Target resources must carry the tag AIOpsManaged=true. System functions (aiops-sys-*) are never touched.
  * Cool-down per (runbook, target) and hard caps on how far Lambda settings may be raised.
  * Every decision is written to DynamoDB (REMEDIATION items) and to the /aiops/audit log group.
"""
import json
import logging
import math
import os
import time

import boto3
import boto3.dynamodb.conditions

from aiops_core import to_ddb, from_ddb, severity_rank, env_list, now_ts, RUNBOOKS
from aiops_core.notify import publish

log = logging.getLogger()
log.setLevel(logging.INFO)

ddb = boto3.resource("dynamodb")
table = ddb.Table(os.environ["STATE_TABLE"])
lam = boto3.client("lambda")
ec2 = boto3.client("ec2")
ssm = boto3.client("ssm")
logs = boto3.client("logs")

MODE = os.environ.get("REMEDIATION_MODE", "approval")
ENABLED = set(env_list(os.environ.get("ENABLED_RUNBOOKS", ",".join(RUNBOOKS)))) & set(RUNBOOKS)
AUTO = set(env_list(os.environ.get("AUTO_RUNBOOKS", "lambda_scale_config,clean_disk")))
SERVICE_ALLOW = set(env_list(os.environ.get("SERVICE_ALLOWLIST", "aiops-dashboard,nginx,httpd")))
COOLDOWN_MIN = int(os.environ.get("COOLDOWN_MIN", "30"))
MAX_TIMEOUT = int(os.environ.get("MAX_LAMBDA_TIMEOUT", "300"))
MAX_MEMORY = int(os.environ.get("MAX_LAMBDA_MEMORY", "2048"))
AUDIT_GROUP = os.environ.get("AUDIT_LOG_GROUP", "/aiops/audit")
DOCS = {"restart_service": os.environ.get("DOC_RESTART_SERVICE"), "clean_disk": os.environ.get("DOC_CLEAN_DISK"),
        "reboot_instance": os.environ.get("DOC_REBOOT", "AWS-RestartEC2Instance")}
AUTOMATION_ROLE = os.environ.get("AUTOMATION_ROLE_ARN", "")
TAG_KEY, TAG_VAL = "AIOpsManaged", "true"


# ------------------------------------------------------------------ helpers
def audit(actor, action, detail):
    rec = json.dumps(dict(actor=actor, action=action, **detail), default=str)
    try:
        stream = time.strftime("%Y-%m-%d", time.gmtime())
        try:
            logs.create_log_stream(logGroupName=AUDIT_GROUP, logStreamName=stream)
        except logs.exceptions.ResourceAlreadyExistsException:
            pass
        logs.put_log_events(logGroupName=AUDIT_GROUP, logStreamName=stream, logEvents=[dict(timestamp=int(time.time() * 1000), message=rec)])
    except Exception as e:  # noqa: BLE001
        log.warning("audit write failed: %s", e)
    log.info(rec)


def _cooldown_active(key):
    it = table.get_item(Key={"pk": "COOLDOWN", "sk": key}).get("Item")
    return bool(it and float(it.get("expires_at", 0)) > now_ts())


def _set_cooldown(key):
    table.put_item(Item=to_ddb(dict(pk="COOLDOWN", sk=key, expires_at=int(now_ts() + COOLDOWN_MIN * 60))))


def _lambda_tags_ok(name):
    if name.startswith("aiops-sys-"):
        return False, "system function"
    cfg = lam.get_function(FunctionName=name)
    tags = cfg.get("Tags", {})
    return tags.get(TAG_KEY) == TAG_VAL, cfg["Configuration"]


def _instance(iid):
    r = ec2.describe_instances(InstanceIds=[iid])["Reservations"]
    if not r:
        return None
    i = r[0]["Instances"][0]
    tags = {t["Key"]: t["Value"] for t in i.get("Tags", [])}
    return dict(id=iid, state=i["State"]["Name"], tags=tags)


# ------------------------------------------------------------------ runbooks
def rb_lambda_scale_config(inc):
    results = []
    for name in inc.get("targets", {}).get("lambda", []):
        key = f"lambda_scale_config#{name}"
        if _cooldown_active(key):
            results.append(dict(target=name, status="skipped", reason="cool-down active"))
            continue
        try:
            ok, cfg = _lambda_tags_ok(name)
        except Exception as e:  # noqa: BLE001
            results.append(dict(target=name, status="skipped", reason=f"lookup failed: {e}"))
            continue
        if not ok:
            results.append(dict(target=name, status="skipped", reason=f"not tagged {TAG_KEY}={TAG_VAL} or protected"))
            continue
        before = dict(timeout=cfg["Timeout"], memory=cfg["MemorySize"])
        new = dict(before)
        if inc["category_id"] == "lambda_timeout":
            new["timeout"] = min(MAX_TIMEOUT, math.ceil(before["timeout"] * 1.5))
        elif inc["category_id"] == "memory":
            new["memory"] = min(MAX_MEMORY, int(math.ceil(before["memory"] * 2 / 64.0) * 64))
        else:
            results.append(dict(target=name, status="skipped", reason="category not supported for this runbook"))
            continue
        if new == before:
            results.append(dict(target=name, status="skipped", reason="already at configured maximum"))
            continue
        lam.update_function_configuration(FunctionName=name, Timeout=new["timeout"], MemorySize=new["memory"])
        _set_cooldown(key)
        results.append(dict(target=name, status="applied", before=before, after=new,
                            rollback=f"aws lambda update-function-configuration --function-name {name} --timeout {before['timeout']} --memory-size {before['memory']}"))
    return results


def _ssm_instance_runbook(inc, runbook):
    results = []
    doc = DOCS.get(runbook)
    if not doc:
        return [dict(status="skipped", reason=f"no SSM document configured for {runbook}")]
    for iid in inc.get("targets", {}).get("instances", []):
        key = f"{runbook}#{iid}"
        if _cooldown_active(key):
            results.append(dict(target=iid, status="skipped", reason="cool-down active"))
            continue
        try:
            inst = _instance(iid)
        except Exception as e:  # noqa: BLE001
            results.append(dict(target=iid, status="skipped", reason=f"lookup failed: {e}"))
            continue
        if not inst or inst["state"] != "running" or inst["tags"].get(TAG_KEY) != TAG_VAL:
            results.append(dict(target=iid, status="skipped", reason=f"instance missing, not running or not tagged {TAG_KEY}={TAG_VAL}"))
            continue
        params = {"InstanceId": [iid], "AutomationAssumeRole": [AUTOMATION_ROLE]}
        if runbook == "restart_service":
            svc = inst["tags"].get("AIOpsService", "")
            if svc not in SERVICE_ALLOW:
                results.append(dict(target=iid, status="skipped", reason=f"tag AIOpsService='{svc}' is not in the service allow-list"))
                continue
            params["ServiceName"] = [svc]
        ex = ssm.start_automation_execution(DocumentName=doc, Parameters=params)
        _set_cooldown(key)
        results.append(dict(target=iid, status="started", automation_execution_id=ex["AutomationExecutionId"], document=doc))
    return results or [dict(status="skipped", reason="incident has no instance targets")]


RUNBOOK_FN = {
    "lambda_scale_config": rb_lambda_scale_config,
    "restart_service": lambda inc: _ssm_instance_runbook(inc, "restart_service"),
    "reboot_instance": lambda inc: _ssm_instance_runbook(inc, "reboot_instance"),
    "clean_disk": lambda inc: _ssm_instance_runbook(inc, "clean_disk"),
}


# ------------------------------------------------------------------ orchestration
def execute(inc, actor):
    rb = inc.get("runbook")
    if rb not in RUNBOOKS or rb not in ENABLED:
        out = dict(status="rejected", reason=f"runbook '{rb}' not allow-listed/enabled")
    else:
        try:
            out = dict(status="executed", results=RUNBOOK_FN[rb](inc))
        except Exception as e:  # noqa: BLE001
            log.exception("runbook failed")
            out = dict(status="failed", reason=str(e)[:300])
    rec = dict(pk="REMEDIATION", sk=f"{int(now_ts())}#{inc['id']}", incident_id=inc["id"], title=inc["title"], runbook=rb, actor=actor,
               ts=now_ts(), expires_at=int(now_ts() + 30 * 86400), **out)
    table.put_item(Item=to_ddb(rec))
    table.update_item(Key={"pk": "INCIDENT", "sk": inc["id"]}, UpdateExpression="SET remediation=:r, remediation_state=:s",
                      ExpressionAttributeValues={":r": to_ddb(rec), ":s": out["status"]})
    audit(actor, "remediation", dict(incident=inc["id"], runbook=rb, outcome=out["status"]))
    publish(f"[AIOps] Remediation {out['status']}: {inc['title']}", json.dumps(from_ddb(to_ddb(out)), indent=2, default=str)[:3000])
    return rec


def on_alarm(event):
    items = table.query(KeyConditionExpression=boto3.dynamodb.conditions.Key("pk").eq("INCIDENT"))["Items"]
    cands = [from_ddb(i) for i in items if i.get("status") == "open" and severity_rank(i.get("severity", "low")) >= 2
             and i.get("runbook") not in (None, "none") and not i.get("remediation_state")]
    handled = []
    for inc in cands:
        if MODE == "auto" and inc["runbook"] in AUTO:
            execute(inc, "auto")
            handled.append((inc["id"], "executed"))
        elif MODE in ("approval", "auto"):
            table.update_item(Key={"pk": "INCIDENT", "sk": inc["id"]}, UpdateExpression="SET remediation_state=:s",
                              ExpressionAttributeValues={":s": "pending_approval"})
            publish(f"[AIOps] Approval needed: {inc['title']}",
                    f"Suggested runbook '{inc['runbook']}' for incident {inc['id']}. Open the dashboard > Incidents and click Approve.")
            audit("system", "approval_requested", dict(incident=inc["id"], runbook=inc["runbook"]))
            handled.append((inc["id"], "pending_approval"))
        else:
            audit("system", "suggest_only", dict(incident=inc["id"], runbook=inc["runbook"]))
            handled.append((inc["id"], "suggested"))
    return dict(mode=MODE, alarm=event.get("detail", {}).get("alarmName"), handled=handled)


def lambda_handler(event, context):
    if event.get("action") == "execute":
        item = table.get_item(Key={"pk": "INCIDENT", "sk": event["incident_id"]}).get("Item")
        if not item:
            return dict(error="incident not found")
        inc = from_ddb(item)
        audit(event.get("approved_by", "unknown"), "approved", dict(incident=inc["id"], runbook=inc.get("runbook")))
        return from_ddb(execute(inc, event.get("approved_by", "unknown")))
    if event.get("detail-type") == "CloudWatch Alarm State Change":
        if event["detail"]["state"]["value"] != "ALARM":
            return dict(ignored=True)
        return on_alarm(event)
    return dict(ignored=True, reason="unknown event")
