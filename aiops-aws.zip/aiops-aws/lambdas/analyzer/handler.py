"""AI/ML processing engine: log analysis + anomaly detection + root-cause analysis.

Triggered every few minutes by EventBridge. Reads recent events from CloudWatch Logs, runs the
shared analysis core, stores incidents + a snapshot in DynamoDB, publishes CloudWatch metrics (which
drive the alarms) and asynchronously asks the fixer Lambda (Amazon Bedrock) to diagnose NEW incidents.
"""
import json
import logging
import os
import time
from concurrent.futures import ThreadPoolExecutor

import boto3
from boto3.dynamodb.conditions import Key

from aiops_core import (parse_event, detect_anomalies, mine_patterns, risk_scores, build_incidents, severity_rank,
                        summarize_levels, to_ddb, from_ddb, env_list, now_ts)

log = logging.getLogger()
log.setLevel(logging.INFO)

logs = boto3.client("logs")
ddb = boto3.resource("dynamodb")
cw = boto3.client("cloudwatch")
lam = boto3.client("lambda")

TABLE = os.environ["STATE_TABLE"]
PREFIXES = env_list(os.environ.get("LOG_GROUP_PREFIXES", "/aws/lambda/,/aws/ecs/,/aws/rds/,/aws/apigateway/,/aws/eks/,/aiops/app/,/aiops/demo/,/aws/events/"))
EXCLUDE = env_list(os.environ.get("EXCLUDE_PREFIXES", "/aws/lambda/aiops-sys-"))
LOOKBACK_MIN = int(os.environ.get("LOOKBACK_MIN", "60"))
WINDOW_MIN = int(os.environ.get("WINDOW_MIN", "10"))
MAX_GROUPS = int(os.environ.get("MAX_GROUPS", "60"))
MAX_EVENTS = int(os.environ.get("MAX_EVENTS_PER_GROUP", "3000"))
Z = float(os.environ.get("Z_THRESHOLD", "3.0"))
CORR_WINDOW = float(os.environ.get("CORRELATION_WINDOW_MIN", "5"))
NAMESPACE = os.environ.get("METRIC_NAMESPACE", "AIOps")
FIXER = os.environ.get("FIXER_FUNCTION")
SNS_ARN = os.environ.get("SNS_TOPIC_ARN")
INCIDENT_TTL_DAYS = 30


def list_groups():
    groups = []
    for p in PREFIXES:
        pager = logs.get_paginator("describe_log_groups")
        for page in pager.paginate(logGroupNamePrefix=p):
            for g in page["logGroups"]:
                n = g["logGroupName"]
                if any(n.startswith(x) for x in EXCLUDE):
                    continue
                groups.append(n)
    return sorted(set(groups))[:MAX_GROUPS]


def fetch(group, start_ms, end_ms):
    out = []
    try:
        pager = logs.get_paginator("filter_log_events")
        for page in pager.paginate(logGroupName=group, startTime=start_ms, endTime=end_ms,
                                   PaginationConfig={"MaxItems": MAX_EVENTS}):
            for e in page["events"]:
                out.append(parse_event(group, e.get("logStreamName", ""), e["timestamp"], e["message"]))
    except Exception as ex:  # noqa: BLE001 - one broken group must not stop the run
        log.warning("fetch failed for %s: %s", group, ex)
    return out


def _existing_open(table):
    items, kw = [], dict(KeyConditionExpression=Key("pk").eq("INCIDENT"))
    while True:
        r = table.query(**kw)
        items += r["Items"]
        if "LastEvaluatedKey" not in r:
            break
        kw["ExclusiveStartKey"] = r["LastEvaluatedKey"]
    return [from_ddb(i) for i in items if i.get("status") in ("open", "acknowledged")]


def lambda_handler(event, context):
    t0 = time.time()
    now = now_ts()
    start_ms, end_ms = int((now - LOOKBACK_MIN * 60) * 1000), int(now * 1000)
    groups = list_groups()
    with ThreadPoolExecutor(max_workers=8) as ex:
        events = [e for batch in ex.map(lambda g: fetch(g, start_ms, end_ms), groups) for e in batch]
    events.sort(key=lambda e: e.ts)
    log.info("fetched %d events from %d groups", len(events), len(groups))

    since = now - WINDOW_MIN * 60
    anomalies = detect_anomalies(events, since=since, z_thresh=Z)
    incidents = build_incidents(anomalies, events, window_min=CORR_WINDOW)
    patterns = mine_patterns([e for e in events if e.ts >= since], top=25)
    risk = risk_scores(events, now, WINDOW_MIN)

    table = ddb.Table(TABLE)
    existing = _existing_open(table)
    new_ids, high_new = [], []
    for inc in incidents:
        match = next((x for x in existing if x["root_service"] == inc["root_service"] and x["category_id"] == inc["category_id"]
                      and inc["start_ts"] - x["end_ts"] <= 30 * 60), None)
        if match:  # same ongoing incident -> extend it (partial update: never clobber the AI diagnosis, status or remediation state)
            sev = inc["severity"] if severity_rank(inc["severity"]) > severity_rank(match["severity"]) else match["severity"]
            table.update_item(
                Key={"pk": "INCIDENT", "sk": match["id"]},
                UpdateExpression="SET end_ts=:e, event_count=:c, services=:sv, samples=:sa, score=:sc, burst=:b, targets=:t, severity=:sev, expires_at=:x",
                ExpressionAttributeValues=to_ddb({":e": max(match["end_ts"], inc["end_ts"]), ":c": max(match["event_count"], inc["event_count"]),
                                                  ":sv": inc["services"], ":sa": inc["samples"], ":sc": max(match.get("score", 0), inc["score"]),
                                                  ":b": bool(match.get("burst") or inc["burst"]), ":t": inc["targets"], ":sev": sev,
                                                  ":x": int(now + INCIDENT_TTL_DAYS * 86400)}))
            continue
        inc.update(created_ts=now, pk="INCIDENT", sk=inc["id"], expires_at=int(now + INCIDENT_TTL_DAYS * 86400))
        new_ids.append(inc["id"])
        if severity_rank(inc["severity"]) >= 2:
            high_new.append(inc)
        table.put_item(Item=to_ddb(inc))

    # keep incident resolved automatically when quiet for 2 windows
    for x in existing:
        if now - x["end_ts"] > 2 * LOOKBACK_MIN * 60 and x["status"] == "open":
            table.update_item(Key={"pk": "INCIDENT", "sk": x["id"]}, UpdateExpression="SET #s=:r",
                              ExpressionAttributeNames={"#s": "status"}, ExpressionAttributeValues={":r": "auto-resolved"})

    snapshot = dict(pk="SNAPSHOT", sk="latest", ts=now, groups=len(groups), events=len(events), window_min=WINDOW_MIN,
                    lookback_min=LOOKBACK_MIN, levels=summarize_levels([e for e in events if e.ts >= since]),
                    risk=risk[:20], patterns=[{**p, "services": p["services"]} for p in patterns],
                    anomalies=[{**a, "message": a["message"][:160]} for a in anomalies[-60:]],
                    anomaly_count=len(anomalies), duration_s=round(time.time() - t0, 2),
                    expires_at=int(now + 7 * 86400))
    table.put_item(Item=to_ddb(snapshot))

    # --- metrics that drive CloudWatch alarms
    open_now = [i for i in incidents if i["end_ts"] >= since]
    md = [
        dict(MetricName="HighSeverityIncidents", Value=float(sum(1 for i in open_now if severity_rank(i["severity"]) >= 2)), Unit="Count"),
        dict(MetricName="TotalIncidents", Value=float(len(open_now)), Unit="Count"),
        dict(MetricName="AnomalyCount", Value=float(len([a for a in anomalies if a["kind"] != "latency"])), Unit="Count"),
        dict(MetricName="MaxRiskScore", Value=float(risk[0]["risk"] if risk else 0), Unit="None"),
        dict(MetricName="EventsAnalyzed", Value=float(len(events)), Unit="Count"),
    ]
    for r in risk[:10]:
        md.append(dict(MetricName="RiskScore", Dimensions=[{"Name": "Service", "Value": r["service"][:200]}], Value=float(r["risk"]), Unit="None"))
    for i in range(0, len(md), 20):
        cw.put_metric_data(Namespace=NAMESPACE, MetricData=md[i:i + 20])

    # --- GenAI diagnosis for NEW incidents (async so analysis never waits on the LLM)
    if FIXER:
        for iid in new_ids:
            lam.invoke(FunctionName=FIXER, InvocationType="Event", Payload=json.dumps({"incident_id": iid}).encode())

    res = dict(groups=len(groups), events=len(events), anomalies=len(anomalies), incidents=len(incidents), new=new_ids,
               seconds=round(time.time() - t0, 2))
    log.info(json.dumps(res))
    return res
