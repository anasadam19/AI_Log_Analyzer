"""GenAI fix engine: asks Amazon Bedrock to diagnose an incident and propose remediation.

Falls back to the rule-based hint if the model call fails, so the pipeline never blocks on the LLM.
"""
import logging
import os

import boto3

from aiops_core import to_ddb, from_ddb, RUNBOOKS, now_ts
from aiops_core.llm import converse, extract_json, build_fix_prompt, FIX_SYSTEM, LLMError, model_id
from aiops_core.notify import publish

log = logging.getLogger()
log.setLevel(logging.INFO)

table = boto3.resource("dynamodb").Table(os.environ["STATE_TABLE"])


def _fallback(inc, err):
    return dict(source="rule-based", error=str(err)[:300], summary=f"{inc['title']}. {inc['hint']}",
                probable_root_cause=f"{inc['category']} originating in {inc['root_service']}", confidence=inc.get("confidence", 0.3),
                evidence=[s["message"][:200] for s in inc.get("samples", [])[:3]],
                recommended_actions=[dict(step=inc["hint"], how="See AWS documentation for the affected service", risk="low")],
                runbook=inc.get("runbook") or "none", prevention=[])


def lambda_handler(event, context):
    iid = event["incident_id"]
    item = table.get_item(Key={"pk": "INCIDENT", "sk": iid}).get("Item")
    if not item:
        return {"error": "incident not found", "id": iid}
    inc = from_ddb(item)
    try:
        r = converse(FIX_SYSTEM, [{"role": "user", "content": build_fix_prompt(inc)}], max_tokens=1400, temperature=0.1)
        ai = extract_json(r["text"])
        ai.update(source="bedrock", model=r["model"], input_tokens=r["input_tokens"], output_tokens=r["output_tokens"], generated_ts=now_ts())
    except (LLMError, ValueError, KeyError) as e:
        log.warning("LLM diagnosis failed, using fallback: %s", e)
        ai = _fallback(inc, e)
        ai["generated_ts"] = now_ts()
    # Safety: the model may only SUGGEST an allow-listed runbook; anything else is dropped.
    rb = str(ai.get("runbook", "none")).strip()
    ai["runbook"] = rb if rb in RUNBOOKS else "none"
    runbook, ai["runbook_source"] = None, "none"
    if ai["runbook"] != "none":
        runbook, ai["runbook_source"] = ai["runbook"], "llm"
    elif inc.get("runbook") and (ai.get("source") == "rule-based" or float(inc.get("confidence", 0)) >= 0.9):
        # model suggested nothing / failed, but a highly specific signature maps to a bounded runbook
        runbook, ai["runbook_source"] = inc["runbook"], "signature"
    table.update_item(Key={"pk": "INCIDENT", "sk": iid}, UpdateExpression="SET ai=:a, runbook=:r",
                      ExpressionAttributeValues={":a": to_ddb(ai), ":r": runbook or "none"})
    if inc["severity"] in ("high", "critical"):
        publish(f"[AIOps] {inc['severity'].upper()} incident: {inc['title']}",
                f"{ai.get('summary', '')}\n\nProbable root cause: {ai.get('probable_root_cause', '')}\nConfidence: {ai.get('confidence')}\n"
                f"Suggested runbook: {runbook or 'none'}\nIncident id: {iid}\nOpen the dashboard for details and approval.")
    return {"incident_id": iid, "source": ai.get("source"), "runbook": runbook or "none"}
