"""Tiny demo function used to test the full remediation loop end to end.

It is deployed with Timeout=3s and tag AIOpsManaged=true. Invoke it with {"work": 3.5} several times: it times out,
the analyzer sees 'Task timed out after 3.00 seconds', classifies it as 'Lambda timeout', Bedrock diagnoses it and the
remediator (after approval, or automatically in auto mode) raises the timeout.
"""
import time


def lambda_handler(event, context):
    work = float((event or {}).get("work", 1.0))
    print(f'{{"level":"INFO","message":"processing started work={work}s"}}')
    time.sleep(work)
    print('{"level":"INFO","message":"processing finished"}')
    return {"ok": True, "work": work}
