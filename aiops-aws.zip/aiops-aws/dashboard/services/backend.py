"""Data backends for the dashboard.

AwsBackend   – production: CloudWatch Logs, DynamoDB, S3, Lambda, SSM (all via the EC2 instance role)
LocalBackend – offline demo: synthetic logs + in-memory state (AIOPS_BACKEND=local), no AWS needed
"""
from __future__ import annotations

import json
import os
import time
from concurrent.futures import ThreadPoolExecutor

from aiops_core import (parse_event, detect_anomalies, build_incidents, mine_patterns, risk_scores, summarize_levels,
                        to_ddb, from_ddb, env_list, now_ts, severity_rank)
from aiops_core.archive import parse_archive_blob
from aiops_core.simulate import generate


def get_backend():
    return LocalBackend() if os.environ.get("AIOPS_BACKEND", "aws").lower() == "local" else AwsBackend()


# ====================================================================== AWS
class AwsBackend:
    name = "aws"

    def __init__(self):
        import boto3
        from botocore.config import Config
        cfg = Config(retries={"max_attempts": 5, "mode": "standard"}, max_pool_connections=20)
        self.region = os.environ.get("AWS_REGION", "us-east-1")
        self.logs = boto3.client("logs", config=cfg)
        self.s3 = boto3.client("s3", config=cfg)
        self.lam = boto3.client("lambda", config=cfg)
        self.ssm = boto3.client("ssm", config=cfg)
        self.table = boto3.resource("dynamodb").Table(os.environ["STATE_TABLE"])
        self.bucket = os.environ.get("ARCHIVE_BUCKET", "")
        self.analyzer = os.environ.get("ANALYZER_FUNCTION", "")
        self.fixer = os.environ.get("FIXER_FUNCTION", "")
        self.remediator = os.environ.get("REMEDIATOR_FUNCTION", "")
        self.audit_group = os.environ.get("AUDIT_LOG_GROUP", "/aiops/audit")
        self.users_param = os.environ.get("USERS_PARAM", "/aiops/dashboard/users")
        self.prefixes = env_list(os.environ.get("LOG_GROUP_PREFIXES", "/aws/lambda/,/aiops/"))
        self.exclude = (f"/aws/lambda/{os.environ.get('PROJECT', 'aiops')}-sys-",)
        self._users = (0.0, {})

    # ---- users / audit
    def users(self):
        t, u = self._users
        if time.time() - t < 60 and u:
            return u
        try:
            v = self.ssm.get_parameter(Name=self.users_param, WithDecryption=True)["Parameter"]["Value"]
            u = json.loads(v)
        except Exception:  # noqa: BLE001
            u = {}
        self._users = (time.time(), u)
        return u

    def audit(self, user, action, detail=None):
        rec = json.dumps(dict(actor=user, action=action, **(detail or {})), default=str)
        stream = time.strftime("dashboard-%Y-%m-%d", time.gmtime())
        try:
            try:
                self.logs.create_log_stream(logGroupName=self.audit_group, logStreamName=stream)
            except self.logs.exceptions.ResourceAlreadyExistsException:
                pass
            self.logs.put_log_events(logGroupName=self.audit_group, logStreamName=stream,
                                     logEvents=[dict(timestamp=int(time.time() * 1000), message=rec)])
        except Exception:  # noqa: BLE001 - auditing must never break the UI
            pass

    def audit_tail(self, hours=24, limit=300):
        rows = []
        try:
            for page in self.logs.get_paginator("filter_log_events").paginate(
                    logGroupName=self.audit_group, startTime=int((time.time() - hours * 3600) * 1000), PaginationConfig={"MaxItems": limit}):
                for e in page["events"]:
                    try:
                        d = json.loads(e["message"])
                    except ValueError:
                        d = {"raw": e["message"]}
                    d["ts"] = e["timestamp"] / 1000
                    rows.append(d)
        except Exception:  # noqa: BLE001
            pass
        return sorted(rows, key=lambda r: r["ts"], reverse=True)

    # ---- logs
    def list_groups(self, prefixes=None, limit=300):
        out = []
        for p in (prefixes or self.prefixes):
            for page in self.logs.get_paginator("describe_log_groups").paginate(logGroupNamePrefix=p):
                for g in page["logGroups"]:
                    if not any(g["logGroupName"].startswith(x) for x in self.exclude):
                        out.append(dict(name=g["logGroupName"], retention=g.get("retentionInDays"), bytes=g.get("storedBytes", 0)))
        return sorted({g["name"]: g for g in out}.values(), key=lambda g: g["name"])[:limit]

    def archived_status(self, names):
        def one(n):
            try:
                f = self.logs.describe_subscription_filters(logGroupName=n)["subscriptionFilters"]
                return n, any(x["filterName"] == "aiops-archive" for x in f)
            except Exception:  # noqa: BLE001
                return n, None
        with ThreadPoolExecutor(8) as ex:
            return dict(ex.map(one, names))

    def fetch_events(self, groups, start_ts, end_ts, max_per_group=2000):
        def one(g):
            ev = []
            try:
                for page in self.logs.get_paginator("filter_log_events").paginate(
                        logGroupName=g, startTime=int(start_ts * 1000), endTime=int(end_ts * 1000), PaginationConfig={"MaxItems": max_per_group}):
                    for e in page["events"]:
                        ev.append(parse_event(g, e.get("logStreamName", ""), e["timestamp"], e["message"]))
            except Exception:  # noqa: BLE001
                pass
            return ev
        with ThreadPoolExecutor(8) as ex:
            res = [e for b in ex.map(one, groups) for e in b]
        res.sort(key=lambda e: e.ts)
        return res

    # ---- incidents / state
    def snapshot(self):
        it = self.table.get_item(Key={"pk": "SNAPSHOT", "sk": "latest"}).get("Item")
        return from_ddb(it) if it else None

    def incidents(self):
        from boto3.dynamodb.conditions import Key
        items, kw = [], dict(KeyConditionExpression=Key("pk").eq("INCIDENT"))
        while True:
            r = self.table.query(**kw)
            items += r["Items"]
            if "LastEvaluatedKey" not in r:
                break
            kw["ExclusiveStartKey"] = r["LastEvaluatedKey"]
        return sorted((from_ddb(i) for i in items), key=lambda i: i["start_ts"], reverse=True)

    def remediations(self, limit=100):
        from boto3.dynamodb.conditions import Key
        r = self.table.query(KeyConditionExpression=Key("pk").eq("REMEDIATION"), ScanIndexForward=False, Limit=limit)
        return [from_ddb(i) for i in r["Items"]]

    def set_status(self, iid, status, user):
        self.table.update_item(Key={"pk": "INCIDENT", "sk": iid}, UpdateExpression="SET #s=:s, status_by=:u, status_ts=:t",
                               ExpressionAttributeNames={"#s": "status"}, ExpressionAttributeValues={":s": status, ":u": user, ":t": to_ddb(now_ts())})
        self.audit(user, f"incident_{status}", {"incident": iid})

    # ---- actions
    def run_analyzer(self, user):
        self.audit(user, "run_analyzer")
        r = self.lam.invoke(FunctionName=self.analyzer, InvocationType="RequestResponse", Payload=b"{}")
        return json.loads(r["Payload"].read() or b"{}")

    def run_fixer(self, iid, user):
        self.audit(user, "rerun_ai", {"incident": iid})
        r = self.lam.invoke(FunctionName=self.fixer, InvocationType="RequestResponse", Payload=json.dumps({"incident_id": iid}).encode())
        return json.loads(r["Payload"].read() or b"{}")

    def approve(self, iid, user):
        r = self.lam.invoke(FunctionName=self.remediator, InvocationType="RequestResponse",
                            Payload=json.dumps({"action": "execute", "incident_id": iid, "approved_by": user}).encode())
        return json.loads(r["Payload"].read() or b"{}")

    # ---- archive
    def archive_list(self, prefix, limit=200):
        out = []
        for page in self.s3.get_paginator("list_objects_v2").paginate(Bucket=self.bucket, Prefix=prefix, PaginationConfig={"MaxItems": limit}):
            for o in page.get("Contents", []):
                out.append(dict(key=o["Key"], size=o["Size"], modified=o["LastModified"].timestamp()))
        return out

    def archive_events(self, key, max_bytes=15_000_000):
        head = self.s3.head_object(Bucket=self.bucket, Key=key)
        if head["ContentLength"] > max_bytes:
            raise ValueError(f"object is {head['ContentLength'] / 1e6:.1f} MB (> {max_bytes / 1e6:.0f} MB limit)")
        return parse_archive_blob(self.s3.get_object(Bucket=self.bucket, Key=key)["Body"].read())


# ====================================================================== LOCAL (offline demo)
class LocalBackend:
    name = "local"

    def __init__(self):
        self.region = "local"
        self.scenario = os.environ.get("AIOPS_LOCAL_SCENARIO", "db_outage")
        self._state = {}
        self._audit = []
        self._status = {}
        self._rem = []
        self._ai = {}
        self.bucket = "local-archive"

    def users(self):
        import bcrypt
        pw = os.environ.get("LOCAL_ADMIN_PASSWORD", "admin")
        return {"admin": {"hash": bcrypt.hashpw(pw.encode(), bcrypt.gensalt(4)).decode(), "role": "admin"},
                "viewer": {"hash": bcrypt.hashpw(pw.encode(), bcrypt.gensalt(4)).decode(), "role": "viewer"}}

    def audit(self, user, action, detail=None):
        self._audit.append(dict(ts=time.time(), actor=user, action=action, **(detail or {})))

    def audit_tail(self, hours=24, limit=300):
        return list(reversed(self._audit))[:limit]

    def _events(self, minutes=120):
        key = int(time.time() // 60)
        if self._state.get("key") != key:
            rows = generate(time.time(), minutes=minutes, seed=42, scenario=self.scenario)
            self._state = dict(key=key, events=[parse_event(*r) for r in rows])
        return self._state["events"]

    def list_groups(self, prefixes=None, limit=300):
        from aiops_core.simulate import SERVICES
        return [dict(name=f"/aiops/demo/{s}", retention=7, bytes=123456) for s in SERVICES]

    def archived_status(self, names):
        return {n: True for n in names}

    def fetch_events(self, groups, start_ts, end_ts, max_per_group=2000):
        return [e for e in self._events() if start_ts <= e.ts <= end_ts and e.group in groups]

    def _analysis(self):
        ev = self._events()
        now = time.time()
        an = detect_anomalies(ev, since=now - 600)
        return ev, an, build_incidents(an, ev)

    def snapshot(self):
        ev, an, _ = self._analysis()
        now = time.time()
        w = [e for e in ev if e.ts >= now - 600]
        return dict(ts=now, groups=5, events=len(ev), window_min=10, lookback_min=120, levels=summarize_levels(w), risk=risk_scores(ev, now)[:20],
                    patterns=mine_patterns(w, 25), anomalies=an[-60:], anomaly_count=len(an), duration_s=0.1)

    def incidents(self):
        _, _, inc = self._analysis()
        out = []
        for i in inc:
            i = dict(i)
            i["status"] = self._status.get(i["id"], "open")
            if i["id"] in self._ai:
                i["ai"] = self._ai[i["id"]]
            rem = next((r for r in self._rem if r["incident_id"] == i["id"]), None)
            if rem:
                i["remediation"], i["remediation_state"] = rem, rem["status"]
            out.append(i)
        return out

    def remediations(self, limit=100):
        return list(reversed(self._rem))[:limit]

    def set_status(self, iid, status, user):
        self._status[iid] = status
        self.audit(user, f"incident_{status}", {"incident": iid})

    def run_analyzer(self, user):
        self._state = {}
        self.audit(user, "run_analyzer")
        return {"incidents": len(self._analysis()[2]), "local": True}

    def run_fixer(self, iid, user):
        from aiops_core.llm import converse, extract_json, build_fix_prompt, FIX_SYSTEM
        inc = next(i for i in self.incidents() if i["id"] == iid)
        ai = extract_json(converse(FIX_SYSTEM, [{"role": "user", "content": build_fix_prompt(inc)}])["text"])
        ai.update(source="mock", model="mock")
        self._ai[iid] = ai
        self.audit(user, "rerun_ai", {"incident": iid})
        return {"source": "mock"}

    def approve(self, iid, user):
        inc = next(i for i in self.incidents() if i["id"] == iid)
        rec = dict(incident_id=iid, title=inc["title"], runbook=inc.get("runbook") or "none", actor=user, ts=time.time(), status="executed",
                   results=[dict(target="(simulated)", status="applied")])
        self._rem.append(rec)
        self.audit(user, "approved", {"incident": iid})
        return rec

    def archive_list(self, prefix, limit=200):
        return [dict(key=f"{prefix}sample-{i}.gz", size=1000 * (i + 1), modified=time.time() - i * 300) for i in range(3)]

    def archive_events(self, key, max_bytes=0):
        return self._events()[:3000]
