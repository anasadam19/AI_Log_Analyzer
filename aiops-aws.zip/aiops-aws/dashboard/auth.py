"""Login for the dashboard: bcrypt-hashed users (SSM SecureString), roles, idle time-out, brute-force lock-out."""
from __future__ import annotations

import os
import time

import bcrypt
import streamlit as st

IDLE_TIMEOUT_S = int(os.environ.get("SESSION_TIMEOUT_MIN", "30")) * 60
MAX_FAILS, LOCK_S = 5, 300
_DUMMY = bcrypt.hashpw(b"dummy-password", bcrypt.gensalt(10))

ROLE_CAN = {
    "viewer": {"view"},
    "operator": {"view", "ack", "analyze", "rediagnose", "chat"},
    "admin": {"view", "ack", "analyze", "rediagnose", "chat", "approve"},
}


def can(role: str, action: str) -> bool:
    return action in ROLE_CAN.get(role, set())


@st.cache_resource
def _failures():
    return {}  # username -> (fail_count, locked_until)


def verify(username: str, password: str, users: dict):
    """Return role or None. Always performs one bcrypt check so timing does not reveal valid usernames."""
    rec = users.get(username)
    hashed = rec["hash"].encode() if rec else _DUMMY
    try:
        ok = bcrypt.checkpw(password.encode(), hashed)
    except ValueError:
        ok = False
    return rec["role"] if (ok and rec) else None


def login_gate(backend):
    """Render the login form until the user is authenticated. Returns (username, role)."""
    a = st.session_state.get("auth")
    if a:
        if time.time() - a["last_seen"] > IDLE_TIMEOUT_S:
            backend.audit(a["user"], "session_timeout")
            st.session_state.pop("auth", None)
            st.warning("Session expired due to inactivity. Please sign in again.")
        else:
            a["last_seen"] = time.time()
            return a["user"], a["role"]

    st.title("AIOps Platform")
    st.caption("Sign in to continue")
    if backend.name == "local":
        st.info("Local demo mode - sign in as **admin** (password from LOCAL_ADMIN_PASSWORD, default 'admin'). No AWS access is used.")
    with st.form("login"):
        u = st.text_input("Username")
        p = st.text_input("Password", type="password")
        go = st.form_submit_button("Sign in", type="primary")
    if go:
        fails = _failures()
        n, until = fails.get(u, (0, 0))
        if until > time.time():
            st.error(f"Too many failed attempts. Try again in {int(until - time.time())} s.")
            backend.audit(u or "?", "login_blocked")
            st.stop()
        users = backend.users()
        if not users:
            st.error("No users configured. Create one with scripts/create_user.py.")
            st.stop()
        role = verify(u, p, users)
        if role:
            fails.pop(u, None)
            st.session_state["auth"] = dict(user=u, role=role, last_seen=time.time())
            backend.audit(u, "login_ok", {"role": role})
            st.rerun()
        n += 1
        fails[u] = (n, time.time() + LOCK_S if n >= MAX_FAILS else 0)
        backend.audit(u or "?", "login_failed", {"attempt": n})
        time.sleep(min(2 ** n, 8) * 0.25)
        st.error("Invalid username or password.")
    st.stop()


def logout(backend):
    a = st.session_state.pop("auth", None)
    if a:
        backend.audit(a["user"], "logout")
    st.rerun()
