"""AIOps dashboard (Streamlit) - runs on its own EC2 instance behind an ALB."""
import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "shared"))  # repo layout; bundle has ./aiops_core

import pandas as pd
import plotly.express as px
import streamlit as st

from aiops_core import (detect_anomalies, build_incidents, mine_patterns, risk_scores, summarize_levels, iso, redact, severity_rank)
from aiops_core.llm import converse_stream, chat_system, LLMError, provider, model_id
import auth
from services.backend import get_backend

st.set_page_config(page_title="AIOps Platform", page_icon="🛰️", layout="wide")


@st.cache_resource
def backend():
    return get_backend()


B = backend()
USER, ROLE = auth.login_gate(B)

SEV_COLOR = {"critical": "#B91C1C", "high": "#EA580C", "medium": "#CA8A04", "low": "#2563EB"}
LEVEL_COLOR = {"DEBUG": "#9CA3AF", "INFO": "#3B82F6", "WARN": "#F59E0B", "ERROR": "#EF4444", "CRITICAL": "#7F1D1D"}


# ------------------------------------------------------------------ sidebar
with st.sidebar:
    st.markdown("### 🛰️ AIOps Platform")
    st.caption(f"Signed in as **{USER}** ({ROLE}) · backend: `{B.name}` · region: `{B.region}`")
    if st.button("Sign out", width="stretch"):
        auth.logout(B)
    st.divider()
    lookback = st.select_slider("Look-back window", options=[15, 30, 60, 120, 240, 720], value=60, format_func=lambda m: f"{m} min" if m < 120 else f"{m // 60} h")
    max_per_group = st.select_slider("Max events per log group", options=[500, 1000, 2000, 5000], value=2000)
    all_groups = B.list_groups() if "groups" not in st.session_state else st.session_state["groups"]
    st.session_state["groups"] = all_groups
    names = [g["name"] for g in all_groups]
    sel_groups = st.multiselect("Log groups", names, default=names[:25], help="Groups analysed in the live tabs")
    if st.button("🔄 Refresh data", width="stretch"):
        st.cache_data.clear()
        st.session_state.pop("groups", None)
        st.rerun()
    st.caption(f"LLM: `{provider()}` · `{model_id() if provider() == 'bedrock' else os.environ.get('OLLAMA_MODEL', 'mock')}`")


@st.cache_data(ttl=30, show_spinner="Reading logs from CloudWatch…")
def load_events(groups: tuple, minutes: int, per_group: int, _bucket: int):
    now = time.time()
    return B.fetch_events(list(groups), now - minutes * 60, now, per_group)


@st.cache_data(ttl=10, show_spinner=False)
def _incidents(_b, _bucket: int):
    return _b.incidents()


@st.cache_data(ttl=10, show_spinner=False)
def _snapshot(_b, _bucket: int):
    return _b.snapshot()


def get_incidents():
    return _incidents(B, int(time.time() // 10))


def get_snapshot():
    return _snapshot(B, int(time.time() // 10))


events = load_events(tuple(sel_groups), lookback, max_per_group, int(time.time() // 30)) if sel_groups else []
now = time.time()

tabs = st.tabs(["📊 Overview", "📜 Live logs", "🚨 Anomalies", "🧭 Incidents & RCA", "🧩 Patterns", "🗄️ S3 archive",
                "🤖 AI assistant", "🛠️ Remediation & audit", "🔌 Log sources"])


def levels_df(evs):
    c = summarize_levels(evs)
    return pd.DataFrame({"level": list(c), "count": list(c.values())})


# ================================================================== 1. Overview
with tabs[0]:
    snap = get_snapshot()
    incs = get_incidents()
    open_incs = [i for i in incs if i.get("status") in ("open", "acknowledged")]
    hi = [i for i in open_incs if severity_rank(i["severity"]) >= 2]
    c = st.columns(5)
    c[0].metric("Open incidents", len(open_incs))
    c[1].metric("High / critical", len(hi))
    c[2].metric("Anomalies (last window)", snap["anomaly_count"] if snap else "–")
    top = (snap or {}).get("risk", [])
    c[3].metric("Highest risk", f"{top[0]['risk']:.0f}" if top else "–", top[0]["service"] if top else None, delta_color="off")
    c[4].metric("Events analysed", f"{snap['events']:,}" if snap else "–", f"{int(now - snap['ts'])} s ago" if snap else None, delta_color="off")
    if auth.can(ROLE, "analyze"):
        if st.button("▶ Run analysis now"):
            with st.spinner("Running the analyzer Lambda…"):
                try:
                    st.success(f"Done: {B.run_analyzer(USER)}")
                    st.cache_data.clear()
                except Exception as e:  # noqa: BLE001
                    st.error(f"Analyzer failed: {e}")
    l, r = st.columns(2)
    with l:
        st.subheader("Service risk")
        if top:
            df = pd.DataFrame(top)
            fig = px.bar(df, x="risk", y="service", orientation="h", color="risk", color_continuous_scale="OrRd", range_color=(0, 100))
            fig.update_layout(height=340, margin=dict(l=0, r=0, t=10, b=0), yaxis=dict(autorange="reversed"), coloraxis_showscale=False)
            st.plotly_chart(fig, width="stretch")
            st.caption("risk = 60% error rate + 25% worsening trend + 15% critical events (per analysis window)")
        else:
            st.info("No analyzer snapshot yet - it appears after the first scheduled run (≤5 min) or click **Run analysis now**.")
    with r:
        st.subheader("Log levels in the look-back window")
        if events:
            st.plotly_chart(px.bar(levels_df(events), x="level", y="count", color="level", color_discrete_map=LEVEL_COLOR)
                            .update_layout(height=340, showlegend=False, margin=dict(l=0, r=0, t=10, b=0)), width="stretch")
        else:
            st.info("No events loaded - pick log groups in the sidebar.")
    st.subheader("Incident timeline")
    if incs:
        tl = pd.DataFrame([dict(incident=i["title"], start=pd.to_datetime(i["start_ts"], unit="s"), end=pd.to_datetime(max(i["end_ts"], i["start_ts"] + 60), unit="s"),
                                severity=i["severity"], status=i.get("status")) for i in incs[:40]])
        fig = px.timeline(tl, x_start="start", x_end="end", y="incident", color="severity", color_discrete_map=SEV_COLOR)
        fig.update_yaxes(autorange="reversed")
        fig.update_layout(height=max(220, 40 * len(tl)), margin=dict(l=0, r=0, t=10, b=0))
        st.plotly_chart(fig, width="stretch")
    else:
        st.success("No incidents recorded.")

# ================================================================== 2. Live logs
with tabs[1]:
    st.subheader("Live logs")
    if not events:
        st.info("No events in the selected window / groups.")
    else:
        c1, c2, c3 = st.columns([2, 2, 3])
        lv = c1.multiselect("Level", ["DEBUG", "INFO", "WARN", "ERROR", "CRITICAL"], default=["WARN", "ERROR", "CRITICAL"])
        svc = c2.multiselect("Service", sorted({e.service for e in events}))
        q = c3.text_input("Contains text")
        flt = [e for e in events if e.level in lv and (not svc or e.service in svc) and (not q or q.lower() in e.message.lower())]
        st.caption(f"{len(flt):,} of {len(events):,} events match")
        df = pd.DataFrame([dict(time=pd.to_datetime(e.ts, unit="s"), service=e.service, level=e.level, message=e.message[:400], latency_ms=e.latency_ms) for e in flt[-1500:]])
        if len(df):
            per = df.set_index("time").groupby([pd.Grouper(freq="1min"), "level"]).size().reset_index(name="count")
            st.plotly_chart(px.bar(per, x="time", y="count", color="level", color_discrete_map=LEVEL_COLOR).update_layout(height=260, margin=dict(l=0, r=0, t=10, b=0)), width="stretch")
            st.dataframe(df.sort_values("time", ascending=False), width="stretch", height=380, hide_index=True)
            st.download_button("Download CSV", df.to_csv(index=False), "logs.csv", "text/csv")

# ================================================================== 3. Anomalies (computed here, live)
with tabs[2]:
    st.subheader("Anomaly detection (z-score)")
    c1, c2, c3 = st.columns(3)
    z = c1.slider("z-score threshold", 2.0, 6.0, 3.0, 0.5)
    win = c2.slider("Analysis window (min)", 5, 60, 10, 5, help="Anomalies are reported in this window; older data forms the baseline")
    corr = c3.slider("Correlation window (min)", 1, 15, 5)
    if events:
        an = detect_anomalies(events, since=now - win * 60, z_thresh=z)
        live_inc = build_incidents(an, events, window_min=corr)
        k = pd.Series([a["kind"] for a in an]).value_counts() if an else pd.Series(dtype=int)
        m = st.columns(4)
        m[0].metric("Anomalies", len(an))
        m[1].metric("Error/critical", int(k.get("error", 0) + k.get("critical", 0)))
        m[2].metric("Latency outliers", int(k.get("latency", 0)))
        m[3].metric("Error bursts", int(k.get("burst", 0)))
        if an:
            df = pd.DataFrame(an)
            df["time"] = pd.to_datetime(df["ts"], unit="s")
            st.plotly_chart(px.scatter(df, x="time", y="score", color="kind", symbol="service", hover_data=["message"], size="score", size_max=14)
                            .update_layout(height=340, margin=dict(l=0, r=0, t=10, b=0)), width="stretch")
            st.dataframe(df[["time", "service", "kind", "score", "message"]].sort_values("time", ascending=False), width="stretch", height=300, hide_index=True)
        else:
            st.success("No anomalies in this window.")
        st.subheader("Correlated incidents (live view)")
        if live_inc:
            st.dataframe(pd.DataFrame([dict(title=i["title"], severity=i["severity"], start=iso(i["start_ts"]), errors=i["event_count"], services=len(i["services"]),
                                            root=i["root_service"], category=i["category"]) for i in live_inc]), width="stretch", hide_index=True)
        else:
            st.caption("No incident clusters.")
    else:
        st.info("No events loaded.")

# ================================================================== 4. Incidents & RCA
with tabs[3]:
    st.subheader("Incidents & root-cause analysis")
    incs = get_incidents()
    if not incs:
        st.success("No incidents have been detected.")
    else:
        f1, f2 = st.columns(2)
        stf = f1.multiselect("Status", ["open", "acknowledged", "resolved", "auto-resolved"], default=["open", "acknowledged"])
        svf = f2.multiselect("Severity", ["critical", "high", "medium", "low"], default=["critical", "high", "medium", "low"])
        shown = [i for i in incs if i.get("status", "open") in stf and i["severity"] in svf]
        if not shown:
            st.info("Nothing matches the filters.")
        else:
            labels = {i["id"]: f"[{i['severity'].upper()}] {i['title']}  ·  {iso(i['start_ts'])}" for i in shown}
            iid = st.selectbox("Incident", list(labels), format_func=labels.get)
            inc = next(i for i in shown if i["id"] == iid)
            m = st.columns(5)
            m[0].metric("Severity", inc["severity"].upper())
            m[1].metric("Status", inc.get("status", "open"))
            m[2].metric("Errors", inc["event_count"])
            m[3].metric("Services", len(inc["services"]))
            m[4].metric("Duration", f"{max(0, inc['end_ts'] - inc['start_ts']) / 60:.0f} min")
            st.markdown(f"**Probable origin:** `{inc['root_service']}`  ·  **Category:** {inc['category']} (rule confidence {inc.get('confidence', 0):.0%})  ·  **Window:** {iso(inc['start_ts'])} → {iso(inc['end_ts'])}")
            l, r = st.columns([3, 2])
            with l:
                st.markdown("##### Top error messages")
                st.dataframe(pd.DataFrame(inc["samples"]), width="stretch", hide_index=True)
            with r:
                st.markdown("##### Affected services")
                sv = pd.DataFrame({"service": list(inc["services"]), "errors": list(inc["services"].values())})
                st.plotly_chart(px.bar(sv, x="errors", y="service", orientation="h").update_layout(height=240, margin=dict(l=0, r=0, t=0, b=0)), width="stretch")
            ai = inc.get("ai")
            st.markdown("##### 🤖 GenAI diagnosis" + (f"  ·  _{ai.get('source')} {ai.get('model', '')}_" if ai else ""))
            if ai:
                st.info(ai.get("summary", ""))
                st.markdown(f"**Probable root cause:** {ai.get('probable_root_cause', '')}  ·  **Confidence:** {ai.get('confidence', '?')}")
                if ai.get("evidence"):
                    st.markdown("**Evidence**\n" + "\n".join(f"- {redact(str(x))}" for x in ai["evidence"]))
                if ai.get("recommended_actions"):
                    st.dataframe(pd.DataFrame(ai["recommended_actions"]), width="stretch", hide_index=True)
                if ai.get("prevention"):
                    st.markdown("**Prevention**\n" + "\n".join(f"- {x}" for x in ai["prevention"]))
                if ai.get("error"):
                    st.caption(f"⚠ LLM unavailable, rule-based fallback shown: {ai['error']}")
            else:
                st.caption("Diagnosis is generated asynchronously after detection - refresh in a few seconds, or re-run it below.")
                st.markdown(f"**Rule-based hint:** {inc.get('hint', '')}")
            rb = inc.get("runbook") or "none"
            rstate = inc.get("remediation_state")
            st.markdown(f"##### 🛠 Remediation  ·  suggested runbook: `{rb}`  ·  state: `{rstate or 'not requested'}`")
            if inc.get("remediation"):
                st.json(inc["remediation"], expanded=False)
            b = st.columns(4)
            if auth.can(ROLE, "ack"):
                if b[0].button("Acknowledge", disabled=inc.get("status") != "open", key=f"ack{iid}"):
                    B.set_status(iid, "acknowledged", USER); st.cache_data.clear(); st.rerun()
                if b[1].button("Resolve", disabled=inc.get("status") in ("resolved", "auto-resolved"), key=f"res{iid}"):
                    B.set_status(iid, "resolved", USER); st.cache_data.clear(); st.rerun()
            if auth.can(ROLE, "rediagnose") and b[2].button("Re-run AI diagnosis", key=f"ai{iid}"):
                with st.spinner("Asking the model…"):
                    try:
                        B.run_fixer(iid, USER); st.cache_data.clear(); st.rerun()
                    except Exception as e:  # noqa: BLE001
                        st.error(str(e))
            if rb != "none":
                if auth.can(ROLE, "approve"):
                    ok = st.checkbox(f"I reviewed the diagnosis and approve running `{rb}` against the tagged targets", key=f"cf{iid}")
                    if st.button("✅ Approve & execute", type="primary", disabled=not ok, key=f"ap{iid}"):
                        with st.spinner("Executing runbook…"):
                            try:
                                st.json(B.approve(iid, USER)); st.cache_data.clear()
                            except Exception as e:  # noqa: BLE001
                                st.error(str(e))
                else:
                    st.caption("Only administrators can approve remediation.")

# ================================================================== 5. Patterns
with tabs[4]:
    st.subheader("Log pattern mining")
    if events:
        only = st.radio("Include", ["All events", "WARN and above", "ERROR and above"], horizontal=True, index=1)
        floor = {"All events": "DEBUG", "WARN and above": "WARN", "ERROR and above": "ERROR"}[only]
        pats = mine_patterns(events, 40, min_level=floor)
        considered = sum(1 for e in events if e.level in {"DEBUG": ("DEBUG", "INFO", "WARN", "ERROR", "CRITICAL"), "WARN": ("WARN", "ERROR", "CRITICAL"), "ERROR": ("ERROR", "CRITICAL")}[floor])
        m = st.columns(3)
        m[0].metric("Events considered", f"{considered:,}")
        m[1].metric("Distinct templates (top shown)", len(pats))
        full = len({p["template"] for p in mine_patterns(events, 100000, min_level=floor)})
        m[2].metric("Compression", f"{considered / max(full, 1):.0f} : 1", f"{full} templates total", delta_color="off")
        df = pd.DataFrame([dict(count=p["count"], level=p["level"], category=p["category"], services=", ".join(p["services"]), template=p["template"],
                                first=iso(p["first_ts"]), last=iso(p["last_ts"])) for p in pats])
        if len(df):
            st.plotly_chart(px.bar(df.head(15), x="count", y="template", orientation="h", color="level", color_discrete_map=LEVEL_COLOR)
                            .update_layout(height=460, yaxis=dict(autorange="reversed", title=None), margin=dict(l=0, r=0, t=10, b=0)), width="stretch")
            st.dataframe(df, width="stretch", hide_index=True)
    else:
        st.info("No events loaded.")

# ================================================================== 6. S3 archive
with tabs[5]:
    st.subheader("S3 long-term archive")
    st.caption(f"Bucket: `{B.bucket}` — CloudWatch Logs are streamed here by Firehose (prefix `cloudwatch-logs/`), CloudTrail writes to `cloudtrail/`.")
    c1, c2, c3 = st.columns(3)
    kind = c1.selectbox("Source", ["cloudwatch-logs/", "cloudtrail/AWSLogs/", "alb/AWSLogs/", "s3-access/", "custom"])
    d = c2.date_input("Date (UTC)", value=pd.Timestamp.now("UTC").date())
    hour = c3.number_input("Hour (UTC, -1 = whole day)", -1, 23, -1)
    if kind == "cloudwatch-logs/":
        prefix = f"cloudwatch-logs/year={d:%Y}/month={d:%m}/day={d:%d}/" + (f"hour={hour:02d}/" if hour >= 0 else "")
    elif kind == "custom":
        prefix = st.text_input("Prefix", "")
    else:
        prefix = kind
    st.code(prefix)
    if st.button("List objects"):
        try:
            st.session_state["arch_list"] = B.archive_list(prefix)
        except Exception as e:  # noqa: BLE001
            st.error(f"Could not list: {e}")
    objs = st.session_state.get("arch_list", [])
    if objs:
        st.dataframe(pd.DataFrame([dict(key=o["key"], size_kb=round(o["size"] / 1024, 1), modified=iso(o["modified"])) for o in objs]), width="stretch", height=220, hide_index=True)
        key = st.selectbox("Object to analyse", [o["key"] for o in objs])
        if st.button("Load & analyse"):
            with st.spinner("Downloading and parsing…"):
                try:
                    st.session_state["arch_events"] = B.archive_events(key)
                except Exception as e:  # noqa: BLE001
                    st.error(str(e))
    ae = st.session_state.get("arch_events")
    if ae:
        st.success(f"Parsed {len(ae):,} events from the archive object")
        t0 = min(e.ts for e in ae)
        an = detect_anomalies(ae, since=None)
        inc = build_incidents(an, ae)
        m = st.columns(3)
        m[0].metric("Events", f"{len(ae):,}")
        m[1].metric("Anomalies", len(an))
        m[2].metric("Incidents", len(inc))
        st.plotly_chart(px.bar(levels_df(ae), x="level", y="count", color="level", color_discrete_map=LEVEL_COLOR).update_layout(height=240, showlegend=False, margin=dict(l=0, r=0, t=10, b=0)), width="stretch")
        st.dataframe(pd.DataFrame([dict(time=iso(e.ts), service=e.service, level=e.level, message=e.message[:300]) for e in ae if e.level in ("WARN", "ERROR", "CRITICAL")][:1000]),
                     width="stretch", height=300, hide_index=True)
        for i in inc:
            st.markdown(f"- **{i['severity'].upper()}** {i['title']} — {i['event_count']} errors, {iso(i['start_ts'])}")

# ================================================================== 7. AI assistant
with tabs[6]:
    st.subheader("AI assistant")
    st.caption("Grounded in your current incidents, risk scores and (optionally) redacted log samples. Powered by Amazon Bedrock.")
    if not auth.can(ROLE, "chat"):
        st.info("Your role is read-only; ask an operator or administrator to use the assistant.")
    else:
        inc_ctx = [i for i in get_incidents() if i.get("status") in ("open", "acknowledged")][:6]
        snap = get_snapshot() or {}
        raw = st.checkbox("Include redacted raw log samples (last 25 error lines)", value=False)
        ctx = ["OPEN INCIDENTS:"] + [f"- [{i['severity']}] {i['title']} | origin={i['root_service']} | {i['event_count']} errors | hint: {i.get('hint', '')} | "
                                      f"AI: {(i.get('ai') or {}).get('summary', 'n/a')}" for i in inc_ctx]
        ctx += ["", "SERVICE RISK (top 6):"] + [f"- {r['service']}: risk {r['risk']}, error_rate {r['error_rate']}" for r in snap.get("risk", [])[:6]]
        ctx += ["", "TOP PATTERNS:"] + [f"- ({p['count']}x) {p['template'][:160]}" for p in snap.get("patterns", [])[:8]]
        if raw:
            errs = [e for e in events if e.level in ("ERROR", "CRITICAL")][-25:]
            ctx += ["", "RECENT ERROR LINES:"] + [f"- {iso(e.ts)} {e.service}: {e.message[:200]}" for e in errs]
        system = chat_system(redact("\n".join(ctx)))
        hist = st.session_state.setdefault("chat", [])
        for m in hist:
            with st.chat_message(m["role"]):
                st.markdown(m["content"])
        sug = st.columns(3)
        picked = None
        for col, text in zip(sug, ["Summarise what is going wrong right now", "What should I check first and why?", "Write the AWS CLI commands to investigate the top incident"]):
            if col.button(text, key=f"sg{text}"):
                picked = text
        prompt = st.chat_input("Ask about incidents, logs, or AWS troubleshooting…") or picked
        if prompt:
            if len([m for m in hist if m["role"] == "user"]) >= 40:
                st.warning("Conversation limit reached - clear the chat to continue.")
            else:
                hist.append({"role": "user", "content": prompt})
                with st.chat_message("user"):
                    st.markdown(prompt)
                with st.chat_message("assistant"):
                    try:
                        answer = st.write_stream(converse_stream(system, hist[-12:], max_tokens=1200))
                    except LLMError as e:
                        answer = f"⚠ The model call failed: {e}"
                        st.error(answer)
                hist.append({"role": "assistant", "content": answer})
                B.audit(USER, "chat", {"chars": len(prompt)})
        if hist and st.button("Clear chat"):
            st.session_state["chat"] = []
            st.rerun()

# ================================================================== 8. Remediation & audit
with tabs[7]:
    st.subheader("Remediation history")
    rem = B.remediations()
    if rem:
        st.dataframe(pd.DataFrame([dict(time=iso(r["ts"]), incident=r.get("title"), runbook=r.get("runbook"), by=r.get("actor"), status=r.get("status"),
                                        detail=str(r.get("results") or r.get("reason") or "")[:300]) for r in rem]), width="stretch", hide_index=True)
    else:
        st.caption("No remediation has been executed yet.")
    st.subheader("Audit log")
    aud = B.audit_tail()
    if aud:
        st.dataframe(pd.DataFrame([{**{k: v for k, v in a.items() if k != "ts"}, "time": iso(a["ts"])} for a in aud]), width="stretch", height=360, hide_index=True)
    else:
        st.caption("Audit log is empty.")

# ================================================================== 9. Log sources
with tabs[8]:
    st.subheader("Log source coverage")
    families = [("Lambda", "/aws/lambda/"), ("ECS", "/ecs/"), ("ECS (aws prefix)", "/aws/ecs/"), ("RDS / Aurora", "/aws/rds/"), ("API Gateway", "/aws/apigateway/"),
                ("EKS control plane", "/aws/eks/"), ("VPC Flow Logs", "/aws/vpc/"), ("CloudTrail", "/aws/cloudtrail/"), ("Service events (GuardDuty, Health, Config…)", "/aws/events/"),
                ("Application logs (EC2 / agents)", "/aiops/app/")]
    cov = [dict(source=n, log_groups=sum(1 for g in all_groups if g["name"].startswith(p)), status="✅" if any(g["name"].startswith(p) for g in all_groups) else "—") for n, p in families]
    st.dataframe(pd.DataFrame(cov), width="stretch", hide_index=True)
    if st.button("Check S3 archive subscription for each group"):
        with st.spinner("Checking subscription filters…"):
            st.session_state["arch_status"] = B.archived_status([g["name"] for g in all_groups[:150]])
    ast = st.session_state.get("arch_status", {})
    df = pd.DataFrame([dict(log_group=g["name"], retention_days=g["retention"] or "never expires", stored_MB=round(g["bytes"] / 1e6, 2),
                            archived_to_s3={True: "✅", False: "❌", None: "?"}.get(ast.get(g["name"]) if g["name"] in ast else None, "not checked")) for g in all_groups])
    st.dataframe(df, width="stretch", height=420, hide_index=True)
    if ast:
        missing = [n for n, v in ast.items() if v is False]
        if missing:
            st.warning(f"{len(missing)} group(s) are not archived. Run `python scripts/enable_log_sources.py --sweep` or invoke the onboarder Lambda with {{\"sweep\": true}}.")
        else:
            st.success("All checked log groups are archived to S3.")
    st.caption("Groups without a retention policy cost money forever - the onboarder Lambda applies the default retention automatically.")
