# AIOps Platform on AWS — End-to-End Guide

Everything below maps 1-to-1 to your architecture diagram. Follow the phases in order; every command can be run from **AWS CloudShell** (no local installs).

| Diagram box | What gets created | Code |
|---|---|---|
| EC2 / ECS / RDS / other sources | Log sources (yours) + auto-enable helpers | `scripts/enable_log_sources.py` |
| Amazon CloudWatch Logs | Central log groups, retention, CloudTrail, VPC Flow Logs, service events | `infra/02-log-aggregation.yaml` |
| Amazon S3 (long-term archive) | Archive bucket + Firehose delivery of **every** log group, lifecycle tiering | `infra/01-foundation.yaml`, `02-…` |
| AI/ML processing engine — Lambda | Log analysis, anomaly detection (z-score), root-cause analysis | `lambdas/analyzer`, `shared/aiops_core` |
| GenAI fix engine | Amazon Bedrock (Converse API) diagnosis + fix plan | `lambdas/fixer`, `shared/aiops_core/llm.py` |
| CloudWatch Alarms → EventBridge | Alarms on engine metrics, rule routing ALARM events | `infra/03-engine.yaml` |
| Automated remediation (Lambda + SSM Automation) | Guard-railed runbooks, approval flow | `lambdas/remediator`, SSM documents |
| Amazon SNS | E-mail (and optional Slack) alerts | `infra/01-…`, `shared/aiops_core/notify.py` |
| EC2 instance — UI application | Streamlit dashboard, login, Bedrock assistant | `dashboard/`, `infra/04-dashboard.yaml` |
| Application Load Balancer | Public entry, HTTPS optional, health checks | `infra/04-dashboard.yaml` |
| Engineers / admins | bcrypt users with roles (viewer / operator / admin) | `scripts/create_user.py`, `dashboard/auth.py` |
| IAM least privilege | One role per function, tag-conditioned write access | all templates |

---

## Lean mode for AWS Free-plan accounts

Free-plan accounts block some services (e.g. Firehose, Bedrock) and limit EC2 to "free-tier eligible" instance types. Deploy with `MODE=lean`:

| | standard | lean |
|---|---|---|
| S3 archive via Firehose | yes | **off** (CloudWatch retention is the only copy; CloudTrail still writes to S3) |
| NAT gateway | yes | **none** |
| ALB | yes | **none** - dashboard on a public-subnet instance, port 8501 open only to `ALLOWED_CIDR` |
| EC2 type | t3.large | **auto-picked** from `aws ec2 describe-instance-types --filters Name=free-tier-eligible,Values=true` |
| LLM | Ollama / Bedrock | Ollama only if the instance has >=4 GB (llama3.2:1b) or 8 GB (llama3.2); otherwise rule-based |

```bash
export AWS_REGION=eu-north-1 MODE=lean ALERT_EMAIL=<real email> ALLOWED_CIDR=<your ip>/32
./scripts/deploy.sh
```
Without an ALB the dashboard is plain HTTP on `http://<public-ip>:8501` (the IP changes if you stop/start the instance). Prefer the SSM port-forward command printed in the outputs and browse `http://localhost:8501`.

---

## Phase 0 — Prerequisites (15 min)

1. **AWS account** and an IAM identity that can create IAM roles, VPC, EC2, Lambda, CloudFormation, S3, Firehose, CloudTrail, DynamoDB, SNS, EventBridge (an admin user/role for the first deploy is simplest; you can lock it down afterwards).
2. **Choose one region** (e.g. `ap-south-1`) and use it for everything.
3. **Bedrock model access.** Open *Amazon Bedrock → Model catalog* in that region and make sure a text model is available to you. Anthropic models ask for a one-time use-case form the first time. Amazon Nova models need no form. You do **not** need to know the exact model id — `deploy.sh` tests candidates and picks one that really answers.
4. **Open AWS CloudShell** (icon in the console toolbar, same region) and upload `aiops-aws.zip` with *Actions → Upload file*, then:
   ```bash
   unzip aiops-aws.zip && cd aiops-aws
   export AWS_REGION=ap-south-1          # your region
   python3 -m pip install --user bcrypt boto3   # needed only for create_user.py
   ```
5. Decide an **alert e-mail**, and the **IP address(es)** allowed to open the dashboard (find yours at <https://checkip.amazonaws.com> from your laptop — *not* from CloudShell).

> Optional but recommended: an **ACM certificate** for a domain you own (so the dashboard runs on HTTPS). Request it in ACM in the same region and keep the ARN.

---

## Phase 1 — Choose the LLM (2 min)

**Free option (default): Ollama.** Nothing to enable. `deploy.sh` installs Ollama on the dashboard instance (t3.large, 40 GB disk) and downloads `llama3.2`. The dashboard **AI assistant** uses it (slower than Bedrock: expect ~10-60 s per answer). Incident diagnosis in the engine is **rule-based** (signature RCA + fix hints), because Lambda cannot reach a model running on the instance. Skip the rest of this phase.
```bash
export LLM_PROVIDER=ollama          # default; optional: export OLLAMA_MODEL=llama3.2
```

**Bedrock option:** `export LLM_PROVIDER=bedrock`, then continue below. Needs Bedrock model access (and a paid AWS account plan).

### Bedrock check (only for LLM_PROVIDER=bedrock)

```bash
python3 scripts/bedrock_check.py
```
Expected: lines like `OK us.anthropic.claude-haiku-4-5-…` and the working id printed last. If everything fails you get a checklist (model access, IAM permission `bedrock:InvokeModel`, region). Use `--list` to see ids available to you, then `export BEDROCK_MODEL_ID=<id>`.

---

## Phase 2 — Deploy (20–25 min, mostly waiting)

```bash
export ALERT_EMAIL=you@example.com
export ALLOWED_CIDR=203.0.113.10/32        # YOUR laptop/office IP
# export CERT_ARN=arn:aws:acm:...           # recommended
# export REMEDIATION_MODE=approval          # suggest | approval (default) | auto
# export ENABLE_DEMO=true                   # demo workload to test the pipeline
./scripts/deploy.sh
```

What happens (each is a CloudFormation stack, so it is repeatable and reversible):

| Stack | Creates | Time |
|---|---|---|
| `aiops-01-foundation` | VPC (2 public + 2 private subnets, NAT, S3 endpoint), **S3 archive bucket** (encrypted, TLS-only, lifecycle), DynamoDB state table, SNS topic (+ e-mail subscription), audit log group | ~4 min |
| `aiops-02-log-aggregation` | Firehose→S3 archive, **onboarder Lambda** (auto-archives every new/existing log group + sets retention), CloudTrail (multi-region, to CloudWatch + S3), VPC Flow Logs, EventBridge rules that capture GuardDuty / Health / Config / EC2 / ECS / RDS / Backup / Inspector / SSM events into CloudWatch Logs | ~3 min |
| `aiops-03-engine` | Analyzer, Fixer (Bedrock), Remediator Lambdas, 4 CloudWatch alarms, EventBridge routing, SSM Automation runbooks, optional demo workload | ~2 min |
| `aiops-04-dashboard` | EC2 (AL2023, private subnet, IMDSv2, encrypted EBS), ALB, target group, security groups | ~6 min |

**Confirm the SNS subscription e-mail** AWS sends you, otherwise no alerts arrive.

At the end the script prints the **DashboardUrl**.

---

## Phase 3 — Create dashboard users (1 min)

```bash
python3 scripts/create_user.py --username admin --role admin      # prompts for a 12+ char password
python3 scripts/create_user.py --username alice --role operator
python3 scripts/create_user.py --username bob   --role viewer
```
Roles: **viewer** read-only · **operator** acknowledge/resolve, run analysis, AI assistant · **admin** also approves remediation.
Passwords are bcrypt-hashed on your machine; only hashes are stored (SSM SecureString). Login failures lock an account for 5 min after 5 tries; sessions expire after 30 idle minutes; every login/approval is written to `/aiops/audit`.

Open the **DashboardUrl** and sign in. (If the page does not load: your IP is not in `ALLOWED_CIDR`, or the instance is still bootstrapping — wait 3–4 minutes. Private alternative without the ALB: the `SsmPortForward` command printed in the stack outputs, then browse `http://localhost:8501`.)

---

## Phase 4 — Aggregate *all possible* AWS service logs

The platform already collects: **Lambda**, **CloudTrail**, **VPC Flow Logs** (AIOps VPC), **service events** (GuardDuty, Security Hub, Health, Config, EC2, Auto Scaling, ECS, RDS, Backup, Inspector, CodeDeploy/Pipeline, SSM), the **dashboard host logs**, and archives every log group to S3.

Turn on more sources — dry-run first, then apply:
```bash
python3 scripts/enable_log_sources.py --all            # shows what WOULD change
python3 scripts/enable_log_sources.py --all --apply
```
This enables: RDS/Aurora log exports, EKS control-plane logs, VPC Flow Logs for every VPC, ALB/NLB access logs → S3, S3 server-access logs → S3, and sweeps all existing log groups into the S3 archive with retention. Sources that need per-resource settings (API Gateway, ECS task definitions, EC2 agents, CloudFront, WAF, Route 53, Step Functions…) are listed with exact steps in **`docs/LOG_SOURCES.md`**.

Check coverage anytime in the dashboard → **Log sources** tab.

> **Cost control:** CloudTrail + VPC Flow Logs + ingestion into CloudWatch are the main log costs. Retention defaults to 30 days in CloudWatch (S3 keeps the long-term copy with tiering). Reduce `LogGroupPrefixes` to analyse only what matters.

---

## Phase 5 — Prove it works end to end (10 min)

Run the health check:
```bash
python3 scripts/verify.py
```
All lines should say `PASS` (the ALB check fails only if your IP is not allowed).

### Test A — multi-service cascade + root cause
```bash
python3 scripts/inject_incident.py --scenario db_outage --wait
```
The demo writer starts emitting a database connection-exhaustion cascade (`payments-db` → `checkout-api` → `gateway`). Within ~3–8 minutes you will see:
1. Dashboard **Overview**: risk bars jump, an incident appears on the timeline.
2. **Incidents & RCA**: *“Database connectivity / connection exhaustion in demo:payments-db (+2 services)”*, severity high/critical, probable origin = the earliest-failing service.
3. A **Bedrock diagnosis** (summary, root cause, evidence, step-by-step actions, prevention).
4. An **e-mail** from SNS, and CloudWatch alarm `aiops-high-severity-incident` in ALARM.

### Test B — the remediation loop (Lambda + SSM/API, with approval)
```bash
python3 scripts/inject_incident.py --scenario lambda_timeout --wait
```
`aiops-demo-flaky` (timeout 3 s) is invoked so that it times out. The engine classifies **Lambda timeout**, Bedrock confirms, the alarm fires, EventBridge calls the remediator, which in `approval` mode marks the incident **pending approval** and e-mails you. In the dashboard open the incident → tick the confirmation → **Approve & execute**. The remediator raises the function’s timeout (3 → 5 s), records before/after + a rollback command, sets a 30-min cool-down, e-mails the outcome and writes the audit trail. Verify:
```bash
aws lambda get-function-configuration --function-name aiops-demo-flaky --query Timeout
```
With `REMEDIATION_MODE=auto`, allow-listed low-risk runbooks (`lambda_scale_config`, `clean_disk`) run without approval; everything else still needs approval.

### Test C — AI assistant
Dashboard → **AI assistant** → “Summarise what is going wrong right now”. It answers from the current incidents / risk / patterns (redacted before leaving the account).

Stop the demo when finished: `aws cloudformation deploy` stack 03 with `EnableDemo=false` (or `./scripts/deploy.sh 3` with `ENABLE_DEMO=false`).

---

## Phase 6 — Point it at your real workloads

1. Make sure your workloads write to CloudWatch Logs (see `LOG_SOURCES.md`). Prefix filters in `LogGroupPrefixes` decide what the engine analyses (default covers Lambda, ECS, RDS, API Gateway, EKS, VPC, CloudTrail, events, app logs).
2. For **EC2 apps** install the CloudWatch agent and ship logs to `/aiops/app/<name>` with stream name `{instance_id}` (the stream name lets the engine find the instance for remediation). Tag instances `AIOpsManaged=true` (and `AIOpsService=<systemd unit>` for the restart runbook; allow-list is `aiops-dashboard,nginx,httpd`).
3. For **Lambda** functions you want auto-tunable, tag them `AIOpsManaged=true`.
4. Give structured JSON logs a `level`, `message` and `latency_ms` field → the best detection quality. Plain text works too (levels and latency are parsed from the text).

---

## Operating the platform

| Task | How |
|---|---|
| Change detection sensitivity | Stack 03 parameters `ZThreshold` (3.0), `WindowMinutes` (10), `LookbackMinutes` (60), `CorrelationWindowMinutes` (5): `aws cloudformation deploy --stack-name aiops-03-engine --template-file infra/03-engine.yaml --capabilities CAPABILITY_NAMED_IAM --parameter-overrides ZThreshold=4 ...` (or edit the defaults and run `./scripts/deploy.sh 3`) |
| Run the analyzer more/less often | Parameter `AnalyzerScheduleExpression` (e.g. `rate(1 minute)` or `rate(15 minutes)`) |
| Switch model | `BEDROCK_MODEL_ID=<id> ./scripts/deploy.sh 3` (stack 04 picks it up on `./scripts/deploy.sh 4`) |
| Change remediation mode | `REMEDIATION_MODE=suggest|approval|auto ./scripts/deploy.sh 3` |
| Update dashboard code fast | `./scripts/update_dashboard.sh` (no instance replacement) |
| Add Slack | `SLACK_WEBHOOK_URL=… ./scripts/deploy.sh 3` |
| Add a new root-cause signature | Edit `shared/aiops_core/rca.py` (`_S` list; specific before generic), rebuild with `./scripts/deploy.sh 3` |
| Add a new runbook | 1) add id to `RUNBOOKS` in `rca.py`; 2) implement in `lambdas/remediator/handler.py` (`RUNBOOK_FN`); 3) add IAM + (optionally) an SSM document in stack 03 |
| Read system logs | `aws logs tail /aws/lambda/aiops-sys-analyzer --since 15m --follow` |
| Query archive with SQL | Create an Athena table over `s3://<archive>/cloudwatch-logs/` (enhancement; see ARCHITECTURE.md) |

---

## Security model (summary)

* **Network:** dashboard instance has no public IP, only the ALB can reach port 8501; ALB only accepts `AllowedCidr`. Use `CERT_ARN` to enable HTTPS (HTTP is redirected).
* **Identity:** one IAM role per function. Remediation write actions are conditioned on the resource tag `AIOpsManaged=true`; system functions (`aiops-sys-*`) can never be modified; `iam:PassRole` is limited to the SSM role.
* **LLM safety:** the model can only *suggest* one of four allow-listed runbooks (anything else is dropped); data is redacted (keys, tokens, e-mails, IPs, account ids) before being sent; optional Bedrock Guardrail via env `BEDROCK_GUARDRAIL_ID`.
* **Data:** S3 encrypted, public access blocked, TLS-only, lifecycle expiry; DynamoDB encrypted with PITR; EBS encrypted; IMDSv2 required.
* **Audit:** logins, approvals, remediation, chat usage → `/aiops/audit` (365-day retention).
* **Hardening checklist for production:** HTTPS + WAF on the ALB; restrict `AllowedCidr`; use a customer-managed KMS key for S3/DynamoDB/SNS; consider replacing the built-in login with Cognito/IAM Identity Center in front of the ALB; enable GuardDuty; use an organization trail and cross-account log subscriptions for multi-account.

---

## Approximate monthly cost (idle-ish, one region — verify with the AWS Pricing Calculator)

| Item | Rough monthly |
|---|---|
| NAT Gateway (1) | ~$32 + data |
| Application Load Balancer | ~$16–20 |
| EC2 `t3.medium` + 20 GB gp3 | ~$30–35 |
| CloudWatch Logs ingestion/storage, CloudTrail → CWL, Flow Logs | depends on volume (≈ $0.50/GB ingested) |
| Firehose + S3 | small (cents per GB) |
| Lambda, DynamoDB, EventBridge, SNS | a few dollars |
| Bedrock | pennies per incident with a Haiku/Nova-class model |

Biggest levers: remove the NAT (use VPC endpoints), turn off Flow Logs, lengthen the analyzer schedule, stop the demo.

---

## Troubleshooting

| Symptom | Likely cause / fix |
|---|---|
| `bedrock_check.py` all FAIL | Model access not granted / wrong region / missing `bedrock:InvokeModel`. Use `--list`; pick another model; for Anthropic complete the use-case form |
| Stack 04 fails on `AllowedCidr` | Must look like `1.2.3.4/32` |
| Dashboard unreachable | Wait for bootstrap (`aws ssm start-session --target <id>` then `tail /var/log/aiops-bootstrap.log`); check ALB target health; confirm your IP |
| “No users configured” | Run `create_user.py` in the same region |
| No incidents appear | `aws logs tail /aws/lambda/aiops-sys-analyzer`; `verify.py`; make sure the log groups match `LogGroupPrefixes`; lower `Z_THRESHOLD`; remember anomalies need ≥2 error events (or a burst) |
| Incident has “rule-based” diagnosis | Bedrock call failed — see the `ai.error` text in the incident, or the fixer log; re-run diagnosis after fixing access |
| Approve does nothing | Target not tagged `AIOpsManaged=true`, cool-down active, or runbook not applicable; the result JSON in the dashboard states why |
| Too many alerts | Raise `Z_THRESHOLD`, set `REMEDIATION_MODE=suggest`, tighten `LogGroupPrefixes` |
| No e-mail | Confirm the SNS subscription; check spam |
| Archive objects empty/unreadable | Data lands 5 min or 5 MB after the log event; dashboard → *S3 archive* handles Firehose’s concatenated gzip format |

---

## Teardown

```bash
./scripts/teardown.sh                # delete all stacks, keep S3 data
./scripts/teardown.sh --purge-data   # also delete archive/artifact buckets and user list (irreversible)
```

---

## Honest limitations

* The CloudFormation templates, scripts and Lambdas were validated with **cfn-lint, unit tests (moto-mocked AWS), and a UI test**, but **not deployed into a live AWS account by the author**. Expect the first deployment to need small fixes (a quota, a region-specific model id, an IAM tweak); the troubleshooting table covers the common ones.
* Detection is statistical + rules (z-score, burst, template mining, signature RCA). It is fast and explainable but not a trained ML model; Bedrock adds reasoning on top. Quality depends on log structure.
* Incident ids are derived from (origin service, category, 15-minute bucket) and merged when the same origin/category recurs within 30 minutes; very long incidents may split.
* The dashboard keeps sessions in memory: a browser refresh requires logging in again (a security-leaning choice).
