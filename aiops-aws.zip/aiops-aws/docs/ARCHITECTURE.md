# Architecture & design notes

## Data flow

```mermaid
flowchart LR
  subgraph SRC[AWS sources]
    L[Lambda] --- E[EC2 / agents] --- C[ECS / EKS] --- R[RDS] --- O[API GW / ALB / WAF ...]
  end
  SRC -->|logs| CWL[(CloudWatch Logs)]
  CT[CloudTrail] --> CWL
  VF[VPC Flow Logs] --> CWL
  EB1[EventBridge: GuardDuty, Health, Config ...] --> CWL
  CWL -->|subscription filter| FH[Kinesis Firehose] --> S3[(S3 archive)]
  ONB[Onboarder Lambda] -.subscribes new groups.-> CWL
  SCH[EventBridge schedule 5 min] --> AN[Analyzer Lambda<br/>parse - z-score - patterns - RCA - correlate]
  CWL --> AN
  AN -->|incidents + snapshot| DDB[(DynamoDB)]
  AN -->|metrics AIOps/*| CWM[CloudWatch Alarms]
  AN -->|async| FX[Fixer Lambda]
  FX -->|Converse API| BR[[Amazon Bedrock]]
  FX --> DDB
  CWM -->|state change ALARM| EB2[EventBridge]
  EB2 --> RM[Remediator Lambda]
  RM -->|allow-listed runbooks| SSM[SSM Automation / Lambda API]
  RM --> SNS[SNS e-mail / Slack]
  FX --> SNS
  USER((Engineer)) --> ALB[ALB] --> UI[EC2: Streamlit dashboard]
  UI --> DDB
  UI --> CWL
  UI --> S3
  UI -->|chat| BR
  UI -->|approve| RM
```

## Why Lambdas are not inside the VPC
They only talk to AWS public service endpoints (CloudWatch Logs, DynamoDB, Bedrock, SNS). Putting them in the VPC would need NAT/VPC endpoints for each service and adds cold-start latency, with no security gain here: access is controlled by IAM. The only VPC resources are the ALB and the dashboard instance.

## Engine algorithm (per run, every 5 min)
1. List log groups matching the prefixes (excluding the system's own), fetch the last `LOOKBACK_MIN` minutes in parallel (8 threads, ≤3000 events/group).
2. **Parse** every line into `Event(ts, service, level, message, latency)`; understands JSON apps, Lambda REPORT/timeout lines, CloudTrail, EventBridge envelopes (GuardDuty severity → level), VPC flow REJECTs, plain text.
3. **Anomaly detection** on the newest `WINDOW_MIN` minutes against the older baseline:
   * severity: each ERROR (2.5) / CRITICAL (4.0)
   * latency: per-service z-score ≥ `Z_THRESHOLD` and > 1.5× baseline mean (needs ≥10 baseline samples)
   * error burst: errors per minute per service, z-score vs baseline buckets (zero buckets included), ≥3 errors
4. **Pattern mining:** messages normalised (UUID, timestamps, IPs, ARNs, hex, numbers → tokens) so thousands of lines collapse to a handful of templates.
5. **RCA:** first-match signature knowledge base (16 signatures, specific → generic) gives category, confidence, hint and an optional allow-listed runbook.
6. **Correlation:** error/critical/burst anomalies closer than `CORRELATION_WINDOW_MIN` (across services) form one incident; the *earliest* service showing the dominant category is the probable origin; severity from error count, services involved, critical events, bursts. Latency-only anomalies are excluded from incidents (weak signal, causes false merging).
7. **Risk:** per service 60 % error rate + 25 % trend + 15 % critical count.
8. Upsert incidents (merge when same origin + category within 30 min), write `SNAPSHOT#latest`, emit metrics `HighSeverityIncidents`, `TotalIncidents`, `AnomalyCount`, `MaxRiskScore`, `EventsAnalyzed`, `RiskScore{Service}`.
9. New incidents → Fixer Lambda (async) → Bedrock JSON diagnosis.

## DynamoDB item model (`aiops-state`, TTL on `expires_at`)
| pk | sk | content |
|---|---|---|
| `INCIDENT` | incident id | incident + `ai` diagnosis + `runbook` + `remediation_state` (30 d) |
| `SNAPSHOT` | `latest` | last analysis: risk, patterns, anomalies, level counts |
| `REMEDIATION` | `<ts>#<incident>` | what was executed, by whom, results, rollback command |
| `COOLDOWN` | `<runbook>#<target>` | prevents repeated changes within `COOLDOWN_MIN` |
| `DEMO` | `scenario` | active demo scenario |

## Remediation guard-rails
`allow-list` (4 runbooks) → `mode` (suggest / approval / auto-for-low-risk) → `tag` (`AIOpsManaged=true`) → `protected` (`aiops-sys-*` never) → `cool-down` → `bounded change` (timeout ×1.5 ≤ 300 s, memory ×2 ≤ 2048 MB) → `SSM role` limited to tagged instances → `audit`. Rollback commands are stored with each action.

| Runbook | Action | Applies when |
|---|---|---|
| `lambda_scale_config` | raise Lambda timeout / memory (bounded) | category Lambda timeout / Memory exhaustion, tagged function |
| `restart_service` | SSM Automation `aiops-RestartService` on tagged instance; service name from tag `AIOpsService` and must be in allow-list | Service crash / unhealthy |
| `clean_disk` | SSM Automation `aiops-CleanDisk` (vacuum journal, delete old rotated logs/tmp) | Disk space exhaustion |
| `reboot_instance` | `AWS-RestartEC2Instance` | only if suggested and approved |

## Enhancements you can add next (Phase-2 ideas)
* Athena + Glue table on the S3 archive for SQL over history; Athena-backed “search the archive” in the dashboard.
* CloudWatch **Logs Insights** queries and **Contributor Insights** for top-N analysis.
* Amazon **Bedrock Knowledge Bases** over your runbooks/postmortems so the fix engine cites your own procedures; **Bedrock Guardrails** (supported via env `BEDROCK_GUARDRAIL_ID`).
* **Amazon DevOps Guru / Lookout-style** managed anomaly detection as a second opinion; train an Isolation-Forest / seasonal model on the archive and replace the z-score detector (the `detect_anomalies` interface stays the same).
* Cognito or IAM Identity Center in front of the ALB (OIDC) instead of the built-in login; WAF.
* Cross-account organisation rollout with a delegated admin account.
* ChatOps: AWS Chatbot / Slack interactive approval button instead of dashboard approval.
