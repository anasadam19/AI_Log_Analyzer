# Getting every AWS service's logs into CloudWatch Logs and S3

Legend — **Auto**: done by this project's stacks · **Script**: `scripts/enable_log_sources.py --apply` · **Manual**: one-time setting per resource.
Everything that lands in CloudWatch Logs is automatically (a) analysed if its group name matches `LogGroupPrefixes` and (b) archived to S3 by the onboarder Lambda.

| Source | How logs reach CloudWatch / S3 | Status | Log-group name |
|---|---|---|---|
| **AWS Lambda** | Automatic | Auto | `/aws/lambda/<fn>` |
| **CloudTrail** (management events) | Trail → CloudWatch Logs + S3 | Auto (stack 02; disable with `ENABLE_CLOUDTRAIL=false` if you already have an org trail) | `/aws/cloudtrail/aiops`, `s3://<archive>/cloudtrail/` |
| **VPC Flow Logs** | Flow log → CloudWatch Logs | Auto for the AIOps VPC; Script for all VPCs | `/aws/vpc/flowlogs/<name or vpc-id>` |
| **GuardDuty, Security Hub, Health, Config, EC2 state, Auto Scaling, ECS events, RDS events, Backup, Inspector, CodeDeploy, CodePipeline, SSM** | EventBridge rule → CloudWatch Logs | Auto (GuardDuty/Security Hub must be *enabled* in the account first) | `/aws/events/aiops-aws-events` |
| **Other CloudWatch alarms** | EventBridge rule → CloudWatch Logs | Auto | same |
| **RDS / Aurora** (error, slow query, postgresql, upgrade, alert, listener, agent) | Log export | Script `--rds` (or console: *Modify → Log exports*) | `/aws/rds/instance/<id>/<type>`, `/aws/rds/cluster/<id>/<type>` |
| **EKS control plane** | Cluster logging | Script `--eks` (audit logs: enable manually, high volume) | `/aws/eks/<cluster>/cluster` |
| **ALB / NLB access logs** | Attribute → S3 | Script `--alb` | `s3://<archive>/alb/AWSLogs/...` |
| **S3 server access logs** | Bucket logging → S3 | Script `--s3-access` | `s3://<archive>/s3-access/<bucket>/` |
| **ECS / Fargate** | Task definition `logConfiguration` `awslogs` driver (`awslogs-group=/ecs/<service>`, `awslogs-region`, `awslogs-stream-prefix`) | Manual per task definition | `/ecs/<service>` |
| **EC2 applications / OS logs** | CloudWatch agent (`amazon-cloudwatch-agent`) `logs_collected.files` → `/aiops/app/<name>`, stream `{instance_id}` | Manual per host (or SSM State Manager association) | `/aiops/app/<name>` |
| **API Gateway** (REST/HTTP) | Stage → *Logs/Tracing* → Access logging destination = a CloudWatch group; REST also needs the account-level CloudWatch role | Manual per stage | `/aws/apigateway/<api>/<stage>` |
| **Step Functions** | State machine → Logging → ALL | Manual | `/aws/vendedlogs/states/<name>` (add this prefix to `LogGroupPrefixes`) |
| **AppSync / CodeBuild / Glue / SageMaker / Kinesis Firehose / MSK** | Service-specific logging setting | Manual | `/aws/<service>/…` (add prefix) |
| **CloudFront** | Standard logging → S3 (or real-time logs) | Manual → point to `s3://<archive>/cloudfront/` (add a bucket-policy statement) | S3 |
| **WAF** | Logging configuration → CloudWatch group named `aws-waf-logs-*`, or Firehose/S3 | Manual | `aws-waf-logs-<name>` (add prefix) |
| **Route 53 Resolver query logs** | Query logging configuration → CloudWatch Logs | Manual | any |
| **AWS Config / Macie / Inspector findings** | EventBridge (above) | Auto for Config & Inspector | events group |
| **Containers on EKS** (application logs) | Fluent Bit / CloudWatch Observability add-on | Manual: `aws eks create-addon --addon-name amazon-cloudwatch-observability` | `/aws/containerinsights/<cluster>/application` (add prefix) |

## Adding a prefix to the analysis
Edit `LogGroupPrefixes` (default in `infra/03-engine.yaml`; dashboard side in `infra/04-dashboard.yaml`) then `./scripts/deploy.sh 3 && ./scripts/deploy.sh 4`.

## How the S3 archive is laid out
```
s3://aiops-archive-<acct>-<region>/
  cloudwatch-logs/year=YYYY/month=MM/day=DD/hour=HH/…   Firehose (gzip batches of every subscribed log group)
  cloudtrail/AWSLogs/<acct>/CloudTrail/<region>/…        CloudTrail log files
  alb/AWSLogs/<acct>/elasticloadbalancing/…              ALB access logs
  s3-access/<bucket>/…                                   S3 server access logs
  firehose-errors/…                                      delivery failures (investigate if present)
```
The dashboard’s **S3 archive** tab reads all of these formats.

## Multi-account / multi-region
* Use an **organization trail** (CloudTrail console → Create trail → *Enable for all accounts*), set `ENABLE_CLOUDTRAIL=false`.
* Send other accounts' logs into this account with a CloudWatch Logs **destination** (cross-account subscription) pointing at the Firehose stream, or deploy the log-aggregation stack in each account/region and replicate the archive buckets.
